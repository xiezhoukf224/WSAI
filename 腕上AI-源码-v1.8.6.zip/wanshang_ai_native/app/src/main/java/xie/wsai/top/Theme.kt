package xie.wsai.top

import android.graphics.Color

data class Theme(
    val bg: Int,
    val surface: Int,
    val surface2: Int,
    val text: Int,
    val dim: Int,
    val border: Int,
    val primary: Int,
    val accent: Int,
    val isDark: Boolean
)

object Themes {
    private fun hex(s: String) = Color.parseColor(s)

    private fun rgba(s: String): Int {
        val m = Regex("rgba\\((\\d+),\\s*(\\d+),\\s*(\\d+),\\s*([0-9.]+)\\)").find(s)
            ?: return Color.parseColor("#33FFFFFF")
        val r = m.groupValues[1].toInt()
        val g = m.groupValues[2].toInt()
        val b = m.groupValues[3].toInt()
        val a = (m.groupValues[4].toFloat() * 255f).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    val cyber = Theme(hex("#0b0b0e"), rgba("rgba(22,22,29,0.82)"), rgba("rgba(42,42,54,0.5)"),
        hex("#f1f1f5"), hex("#9a9aaa"), rgba("rgba(42,42,54,0.55)"), hex("#8b5cf6"), hex("#06b6d4"), true)
    val light = Theme(hex("#f5f5f7"), rgba("rgba(238,238,239,0.85)"), rgba("rgba(221,221,223,0.5)"),
        hex("#16161d"), hex("#6a6a7a"), rgba("rgba(221,221,223,0.55)"), hex("#2563eb"), hex("#0891b2"), false)
    val ocean = Theme(hex("#0e1a2b"), rgba("rgba(26,42,63,0.82)"), rgba("rgba(42,63,90,0.5)"),
        hex("#eaf0f6"), hex("#8aa0b8"), rgba("rgba(42,63,90,0.55)"), hex("#3b82f6"), hex("#0ea5e9"), true)
    val green = Theme(hex("#f0faf2"), rgba("rgba(221,240,224,0.85)"), rgba("rgba(184,224,192,0.5)"),
        hex("#1a3a2a"), hex("#2a7a4a"), rgba("rgba(184,224,192,0.55)"), hex("#15803d"), hex("#047857"), false)
    val sand = Theme(hex("#fcf9f2"), rgba("rgba(242,237,228,0.85)"), rgba("rgba(229,221,208,0.5)"),
        hex("#2a241e"), hex("#8a7a6a"), rgba("rgba(229,221,208,0.55)"), hex("#ea580c"), hex("#d97706"), false)
    val sakura = Theme(hex("#fff5f7"), rgba("rgba(252,228,236,0.85)"), rgba("rgba(248,206,216,0.5)"),
        hex("#4a1a2a"), hex("#9a4a5a"), rgba("rgba(248,206,216,0.55)"), hex("#db2777"), hex("#be185d"), false)
    val neon = Theme(hex("#0a0a0a"), rgba("rgba(26,26,26,0.82)"), rgba("rgba(42,42,42,0.5)"),
        hex("#fafafa"), hex("#8a8a8a"), rgba("rgba(42,42,42,0.55)"), hex("#e11d48"), hex("#f59e0b"), true)
    val galaxy = Theme(hex("#12102a"), rgba("rgba(30,26,58,0.82)"), rgba("rgba(42,36,90,0.5)"),
        hex("#e0daff"), hex("#8a7acc"), rgba("rgba(42,36,90,0.55)"), hex("#8b5cf6"), hex("#fbbf24"), true)

    fun byKey(key: String, dark: Boolean): Theme = when (key) {
        "light" -> light
        "ocean" -> ocean
        "green" -> green
        "sand" -> sand
        "sakura" -> sakura
        "neon" -> neon
        "galaxy" -> galaxy
        "cyber" -> cyber
        else -> if (dark) cyber else light // "auto"
    }
}
