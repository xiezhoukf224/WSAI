package xie.wsai.top

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    /** 待发送附件：type=text/image/binary，content 见 readAttachment 说明 */
    private data class PendingAttachment(
        val name: String,
        val type: String,
        val size: Long,
        val mime: String,
        val content: String
    )

    private lateinit var root: View
    private lateinit var bgImage: ImageView
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var searchInput: EditText
    private lateinit var searchCount: TextView
    private lateinit var btnSearchClear: ImageButton
    private lateinit var rv: RecyclerView
    private lateinit var btnToggleDeep: TextView
    private lateinit var btnToggleWeb: TextView
    private lateinit var btnMic: ImageButton
    private lateinit var quickRow: View
    private lateinit var attachmentBar: LinearLayout
    private lateinit var attIcon: TextView
    private lateinit var attName: TextView
    private lateinit var attMeta: TextView
    private lateinit var input: EditText
    private lateinit var btnAttach: ImageButton
    private lateinit var btnSend: ImageButton
    private lateinit var inputZone: View
    private lateinit var emptyView: View
    private lateinit var logo: TextView
    private lateinit var emptyTitle: TextView
    private lateinit var emptySub: TextView
    private lateinit var btnScrollDown: ImageButton
    private lateinit var topLogo: TextView

    private lateinit var adapter: ChatAdapter
    private val displayMessages = mutableListOf<ChatMessage>()
    private var generating = false
    private var pendingAttachment: PendingAttachment? = null
    private var micDownAt = 0L
    private var theme = Themes.cyber

    /** 手表 / 紧凑屏（最小宽度 < 300dp）：更激进的隐藏与缩放 */
    private val isWatch: Boolean
        get() = resources.configuration.smallestScreenWidthDp < 300
    private lateinit var speech: SpeechHelper
    private var tts: TextToSpeech? = null
    private var logoAnimX: ObjectAnimator? = null
    private var logoAnimY: ObjectAnimator? = null
    private var sendSpin: ObjectAnimator? = null

    // ---------- 流式节流 ----------
    private val uiHandler = Handler(Looper.getMainLooper())
    private var streamTickScheduled = false
    private val STREAM_INTERVAL_MS = 55L
    private val streamTick = object : Runnable {
        override fun run() {
            streamTickScheduled = false
            adapter.updateStreaming()
            scrollIfBottom()
        }
    }
    private fun scheduleStreamFlush() {
        if (streamTickScheduled) return
        streamTickScheduled = true
        uiHandler.postDelayed(streamTick, STREAM_INTERVAL_MS)
    }
    private fun flushStreamNow() {
        uiHandler.removeCallbacks(streamTick)
        streamTickScheduled = false
        adapter.updateStreaming()
    }

    companion object {
        @JvmStatic var pendingClear = false
        private val PROVIDER_LABELS = mapOf(
            "zhipu_free" to "智谱 AI（免费）",
            "deepseek" to "Deepseek",
            "zhipu" to "智谱 AI",
            "qwen" to "阿里通义千问",
            "moonshot" to "Moonshot",
            "openai" to "OpenAI 兼容",
            "custom" to "自定义 API"
        )

        /** 文本/图片最大尺寸限制（解码后才会真正限制，避免巨大文件直接读入内存） */
        private const val MAX_FILE_SIZE = 1024L * 1024 * 1024
        private const val MAX_BINARY_BYTES = 8L * 1024 * 1024  // 二进制：>8MB 仅 base64 前 ~200KB（防止撑爆请求体）
        private const val MAX_B64_CHARS = 220_000               // ~150KB 原文 ≈ 200KB base64，留余量
        private const val MAX_TEXT_CHARS = 120_000              // 文本正文超过则提示用户，截断发送
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        ChatStore.init(this)
        setContentView(R.layout.activity_main)
        bindViews()

        adapter = ChatAdapter(::copy, ::redo, ::speak, ::showMessageMenu)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        rv.setHasFixedSize(true)
        rv.itemAnimator = null  // 流式频繁 notify 时关掉默认动画，避免抖动

        displayMessages.addAll(ChatStore.load())
        adapter.setMessages(displayMessages)

        speech = SpeechHelper(this, object : SpeechHelper.Callback {
            override fun onPartial(text: String) {
                // 实时把识别中的临时结果写回输入框
                runOnUiThread { if (!generating) input.setText(text) }
            }
            override fun onFinal(text: String) {
                runOnUiThread {
                    if (generating) return@runOnUiThread
                    input.setText(text)
                    if (text.isNotBlank()) send(text)
                }
            }
            override fun onError(code: Int) {
                runOnUiThread {
                    val msg = when (code) {
                        SpeechRecognizer.ERROR_AUDIO -> "录音启动失败"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "麦克风权限不足"
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "没听清，请再说一次"
                        SpeechRecognizer.ERROR_NETWORK -> "语音识别网络出错"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_SERVER -> "当前设备没有可用的语音识别服务"
                        else -> "语音识别失败（$code）"
                    }
                    toast(msg)
                    btnMic.animate().alpha(1f).setDuration(150).start()
                }
            }
            override fun onFallback(): Boolean {
                // 没有持续识别服务时，回退到系统语音界面（手表 / 精简 ROM 上必备）
                return runCatching { launchSystemVoice() }.getOrDefault(false)
            }
        })

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.CHINESE
        }

        applyToolToggles()
        setupListeners()
        applyTheme()
        applyCompactMode()
        updateModelSubtitle()
        updateEmptyState()

        if (!Prefs.privacyAgreed) showPrivacy()
    }

    override fun onResume() {
        super.onResume()
        if (pendingClear) {
            pendingClear = false
            displayMessages.clear()
            adapter.setMessages(emptyList())
        }
        applyTheme()
        applyCompactMode()
        updateModelSubtitle()
        updateEmptyState()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacksAndMessages(null)
        speech.destroy()
        tts?.shutdown()
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        bgImage = findViewById(R.id.bgImage)
        titleView = findViewById(R.id.title)
        subtitleView = findViewById(R.id.subtitle)
        searchInput = findViewById(R.id.searchInput)
        searchCount = findViewById(R.id.searchCount)
        btnSearchClear = findViewById(R.id.btnSearchClear)
        rv = findViewById(R.id.rv)
        btnToggleDeep = findViewById(R.id.btnToggleDeep)
        btnToggleWeb = findViewById(R.id.btnToggleWeb)
        btnMic = findViewById(R.id.btnMic)
        quickRow = findViewById(R.id.quickRow)
        attachmentBar = findViewById(R.id.attachmentBar)
        attIcon = findViewById(R.id.attIcon)
        attName = findViewById(R.id.attName)
        attMeta = findViewById(R.id.attMeta)
        input = findViewById(R.id.input)
        btnAttach = findViewById(R.id.btnAttach)
        btnSend = findViewById(R.id.btnSend)
        inputZone = findViewById(R.id.inputZone)
        emptyView = findViewById(R.id.emptyView)
        logo = findViewById(R.id.logo)
        emptyTitle = findViewById(R.id.emptyTitle)
        emptySub = findViewById(R.id.emptySub)
        btnScrollDown = findViewById(R.id.btnScrollDown)
        topLogo = findViewById(R.id.topLogo)
    }

    private fun setupListeners() {
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        Ui.pressScale(findViewById(R.id.btnSettings))

        findViewById<ImageButton>(R.id.btnNewChat).setOnClickListener { confirmNewChat() }
        Ui.pressScale(findViewById(R.id.btnNewChat))

        btnSend.setOnClickListener {
            if (generating) ApiClient.cancel() else send()
        }
        Ui.pressScale(btnSend)
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        // 输入框聚焦时边框高亮
        input.setOnFocusChangeListener { _, hasFocus ->
            val d = resources.displayMetrics.density
            inputZone.background = if (hasFocus)
                Ui.panel(theme.surface, 22f * d, Ui.withAlpha(theme.primary, 210), 1.8f * d)
            else
                Ui.panel(theme.surface, 22f * d, Ui.withAlpha(theme.primary, if (theme.isDark) 70 else 55), 1.5f * d)
        }
        btnAttach.setOnClickListener { attachLauncher.launch("*/*") }
        Ui.pressScale(btnAttach)

        // 长按麦克风：按下启动，松手停止；短按 <250ms 视为误触直接取消
        btnMic.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    btnMic.animate().alpha(0.55f).setDuration(110).start()
                    micDownAt = System.currentTimeMillis()
                    onMicDown()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    btnMic.animate().alpha(1f).setDuration(150).start()
                    if (System.currentTimeMillis() - micDownAt < 250) speech.cancel()
                    else speech.stop()
                    true
                }
                else -> false
            }
        }

        btnToggleDeep.setOnClickListener { onToggleCapability("deep") }
        Ui.pressScale(btnToggleDeep)
        btnToggleWeb.setOnClickListener { onToggleCapability("web") }
        Ui.pressScale(btnToggleWeb)

        val quicks = mapOf(
            R.id.btnQ1 to "总结一下",
            R.id.btnQ2 to "解释一下",
            R.id.btnQ3 to "翻译成英文",
            R.id.btnQ4 to "继续"
        )
        quicks.forEach { (id, txt) ->
            val v = findViewById<TextView>(id)
            v.setOnClickListener { send(txt) }
            Ui.pressScale(v)
        }

        val suggestions = mapOf(
            R.id.sug1 to "帮我写一首关于夏天的诗",
            R.id.sug2 to "解释一下相对论",
            R.id.sug3 to "帮我制定一个健身计划",
            R.id.sug4 to "把下面这段话翻译成英文："
        )
        suggestions.forEach { (id, txt) ->
            val v = findViewById<View>(id)
            v.setOnClickListener { send(txt) }
            Ui.pressScale(v)
        }

        searchInput.doAfterTextChanged { t ->
            val q = t?.toString()?.trim() ?: ""
            adapter.setQuery(q)
            val n = adapter.matchCount()
            searchCount.text = if (q.isEmpty()) "" else if (n > 0) "$n 条" else "无结果"
            btnSearchClear.visibility = if (q.isEmpty()) View.GONE else View.VISIBLE
        }
        btnSearchClear.setOnClickListener {
            searchInput.setText("")
            searchInput.clearFocus()
        }
        findViewById<ImageButton>(R.id.btnAttRemove).setOnClickListener {
            pendingAttachment = null
            renderAttachment()
        }

        btnScrollDown.setOnClickListener { scrollBottom() }
        Ui.pressScale(btnScrollDown)
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                btnScrollDown.visibility =
                    if (rv.canScrollVertically(1) && adapter.itemCount > 0) View.VISIBLE else View.GONE
            }
        })
    }

    private val attachLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) handleAttachUri(uri)
    }
    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoice() else toast("需要麦克风权限才能语音输入")
    }
    /** 系统语音界面回退（手表 / 无持续识别服务的设备必备） */
    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode != RESULT_OK) return@registerForActivityResult
        val list = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val text = list?.firstOrNull()?.trim().orEmpty()
        if (text.isBlank()) { toast("没有识别到语音内容"); return@registerForActivityResult }
        input.setText(text)
        if (!generating) send(text)
    }

    // ---------------- 发送 / 生成 ----------------

    private fun send(textOverride: String? = null) {
        if (generating) return
        val text = (textOverride ?: input.text.toString()).trim()
        val pending = pendingAttachment
        if (text.isEmpty() && pending == null) return

        // API 实际发送的完整正文：保留原文，再附上「结构化附件块」（base64/明文清晰标注）
        val apiPayload = buildApiPayload(text, pending)
        if (apiPayload.isBlank()) return
        val attachments = if (pending == null) emptyList()
            else listOf(Attachment(pending.name, pending.type, pending.size))

        pendingAttachment = null
        renderAttachment()
        input.setText("")

        val time = now()
        val userMsg = ChatMessage("user", text, time, attachments)
        userMsg.apiContent = apiPayload
        displayMessages.add(userMsg)
        adapter.append(userMsg)
        updateEmptyState()
        scrollBottom()
        save()
        generate(apiPayload)
    }

    /**
     * 把「附件」拼成 AI 看得懂的结构化正文：
     * - 文本：BOM/UTF-8/GB18030 自适应解码，绝不再被当成默认 UTF-8 读出乱码
     * - 图片：data URL（base64）+ 明确大小/类型标注
     * - 二进制：base64 + 明确大小/类型标注；超大文件仅截取前 ~200KB 并标注
     * 客户端气泡只显示附件名+类型+大小的小卡片，绝不展示正文。
     */
    private fun buildApiPayload(text: String, pending: PendingAttachment?): String {
        if (pending == null) return text
        val sizeText = FileTypes.sizeText(pending.size)
        val typeLabel = FileTypes.typeLabel(pending.type)
        val header = "[附件：${pending.name} · 类型 ${typeLabel}${if (pending.mime.isNotEmpty()) "/" + pending.mime else ""} · 大小 $sizeText]"
        val note = when (pending.type) {
            "image" -> "（图片已压缩为 JPEG 并 Base64 编码，data URL 在下方；若你不支持可视化，请忽略 Base64 部分）"
            "binary" -> "（以下是文件的 Base64 编码内容，请解码后再处理）"
            else -> "（以下是附件的文本内容，已按文件实际编码解码；中文 txt 多为 GB18030）"
        }
        val bodyPart = when (pending.type) {
            "text" -> {
                val raw = pending.content
                if (raw.length > MAX_TEXT_CHARS)
                    raw.substring(0, MAX_TEXT_CHARS) + "\n…（文本过长，已截断）"
                else raw
            }
            "image", "binary" -> wrapBase64(pending.content)
            else -> pending.content
        }
        val body = if (text.isBlank()) "$header\n$note\n$bodyPart"
        else "$text\n\n$header\n$note\n$bodyPart"
        return body
    }

    /** 把长 base64 折成 76 字符一行，便于 AI / 日志阅读 */
    private fun wrapBase64(s: String): String {
        if (s.length <= 76) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val end = (i + 76).coerceAtMost(s.length)
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(s, i, end)
            i = end
        }
        return sb.toString()
    }

    private fun generate(finalContent: String) {
        val cfg = currentConfig() ?: return
        val cap = Prefs.getCap(Prefs.provider, cfg.model)
        val deepOk = cap == null || cap.deep != CapResult.DEEP_NONE
        val webOk = cap == null || cap.web != CapResult.WEB_NO
        if (Prefs.webSearch && !webOk) toast("实测当前模型（${cfg.model}）不支持联网搜索，已忽略本次搜索请求")
        if (Prefs.deepThink && !deepOk) toast("实测当前模型（${cfg.model}）不输出思考过程，已忽略本次思考请求")
        setGenerating(true)

        // 拼 API 消息：上一条 user 的内容可能含附件，role 仍是 user
        val apiMessages = mutableListOf<JSONObject>()
        val sysPrompt = buildSystemPrompt(webOk, deepOk)
        if (sysPrompt.isNotBlank()) apiMessages.add(msg("system", sysPrompt))
        for (m in displayMessages) {
            if (m.role == "system") continue
            apiMessages.add(msg(if (m.role == "user") "user" else "assistant", m.content))
        }
        // 把最后一条 user 消息的 content 替换为带附件的完整正文
        if (apiMessages.isNotEmpty() && apiMessages.last().optString("role") == "user") {
            apiMessages[apiMessages.size - 1] = msg("user", finalContent)
        } else {
            apiMessages.add(msg("user", finalContent))
        }

        val extra = ApiClient.buildExtra(cfg, Prefs.deepThink && deepOk, Prefs.webSearch && webOk, cap)

        val streamMsg = ChatMessage("assistant", "", now())
        streamMsg.expectingReasoning = Prefs.deepThink && deepOk
        displayMessages.add(streamMsg)
        adapter.startStreaming(streamMsg)
        scrollBottom()

        ApiClient.chatStream(cfg, apiMessages, extra,
            onReasoning = { d -> runOnUiThread {
                streamMsg.reasoning += d
                scheduleStreamFlush()
            } },
            onContent = { d -> runOnUiThread {
                streamMsg.content += d
                scheduleStreamFlush()
            } },
            onDone = { r, c -> runOnUiThread {
                uiHandler.removeCallbacks(streamTick)
                streamTickScheduled = false
                onAiDone(streamMsg, r, c)
            } },
            onError = { e -> runOnUiThread {
                uiHandler.removeCallbacks(streamTick)
                streamTickScheduled = false
                onAiStreamError(streamMsg, e)
            } })
    }

    private fun buildSystemPrompt(webOk: Boolean, deepOk: Boolean): String {
        val sb = StringBuilder()
        val persona = Prefs.systemPrompt.trim()
        if (persona.isNotBlank()) {
            sb.append("你是用户指定的 AI 助手。请严格遵循以下人格设定，在每一次回答的语气、用词、风格和立场上都体现这个人设，不要跳出人设：\n")
                .append(persona)
        }
        if (Prefs.webSearch && webOk) {
            if (sb.isNotEmpty()) sb.append("\n\n")
            sb.append("【联网搜索已开启】当问题涉及最新资讯、实时数据或你无法确定的事实时，请先进行联网检索，")
                .append("基于检索结果回答，并尽量注明信息来源；若检索失败，请明确告知用户。")
        }
        if (Prefs.deepThink && deepOk) {
            if (sb.isNotEmpty()) sb.append("\n\n")
            sb.append("【深度思考已开启】请先进行深入、分步的推理分析，再给出最终回答。")
        }
        return sb.toString()
    }

    private fun onAiDone(m: ChatMessage, reasoning: String, content: String) {
        m.reasoning = reasoning
        m.content = content.ifBlank { "（未获取到有效回复）" }
        adapter.finishStreaming()
        setGenerating(false)
        save()
        scrollBottom()
    }

    private fun onAiStreamError(m: ChatMessage, err: String) {
        setGenerating(false)
        val gotNothing = m.content.isBlank() && m.reasoning.isBlank()
        when {
            err == "已停止" -> {
                if (gotNothing) { removeStreamPlaceholder(m); return }
                m.content = m.content.ifBlank { "（已停止）" }
            }
            gotNothing -> {
                removeStreamPlaceholder(m)
                displayMessages.add(ChatMessage("system", "请求失败：$err", now(), emptyList()))
                adapter.appendSystem("请求失败：$err", now())
                updateEmptyState()
                toast("请求失败，请检查网络或配置")
                save()
                scrollBottom()
                return
            }
            else -> m.content += "\n\n连接中断：$err"
        }
        adapter.finishStreaming()
        save()
        scrollBottom()
    }

    private fun removeStreamPlaceholder(m: ChatMessage) {
        displayMessages.removeAll { it === m }
        adapter.remove(m)
    }

    private fun setGenerating(g: Boolean) {
        generating = g
        btnSend.setImageResource(if (g) R.drawable.ic_stop else R.drawable.ic_send)
        btnSend.setColorFilter(Color.WHITE)
        if (g) {
            sendSpin?.cancel()
            sendSpin = ObjectAnimator.ofFloat(btnSend, View.ROTATION, 0f, 360f).apply {
                duration = 1100
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                start()
            }
        } else {
            sendSpin?.cancel(); sendSpin = null
            btnSend.rotation = 0f
        }
    }

    private fun scrollIfBottom() {
        if (!rv.canScrollVertically(1)) scrollBottom()
    }

    private fun redo() {
        if (generating) return
        if (searchInput.text.isNotEmpty()) searchInput.setText("")
        val aiIdx = displayMessages.indexOfLast { it.role == "assistant" }
        if (aiIdx < 0) return
        displayMessages.removeAt(aiIdx)
        adapter.removeLastAi()
        save()
        val lastUser = displayMessages.lastOrNull { it.role == "user" } ?: return
        // 优先用上次发到 AI 的完整正文（含附件），回退到界面正文
        generate(lastUser.apiContent.ifEmpty { lastUser.content })
    }

    private fun deleteMessage(m: ChatMessage) {
        val idx = displayMessages.indexOfFirst { it === m }
        if (idx < 0) return
        displayMessages.removeAt(idx)
        adapter.remove(m)
        save()
        updateEmptyState()
    }

    private fun showMessageMenu(m: ChatMessage) {
        val items = mutableListOf("复制")
        if (m.role == "assistant") items.add("重新生成")
        items.add("删除")
        AlertDialog.Builder(this)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "复制" -> copy(m.content)
                    "重新生成" -> redo()
                    "删除" -> deleteMessage(m)
                }
            }.show()
    }

    private fun msg(role: String, content: String) = JSONObject().apply {
        put("role", role); put("content", content)
    }

    private fun currentConfig(): ApiConfig? {
        val cfg = currentConfigSilent()
        if (cfg == null && Prefs.provider != "zhipu_free") {
            toast("请先在设置里填好 Base URL / API Key / 模型")
        }
        return cfg
    }

    private fun currentConfigSilent(): ApiConfig? {
        if (Prefs.provider == "zhipu_free") return ApiClient.FREE
        val base = Prefs.baseUrlOf(Prefs.provider).trim()
        val key = Prefs.apiKey(Prefs.provider).trim()
        val model = Prefs.modelNameOf(Prefs.provider).trim()
        if (base.isEmpty() || key.isEmpty() || model.isEmpty()) return null
        return ApiConfig(base, key, model)
    }

    private fun save() = ChatStore.save(displayMessages)
    private fun updateEmptyState() {
        val show = displayMessages.isEmpty()
        emptyView.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            emptySub.text = "${greeting()}，今天想聊点什么？"
            startLogoAnim()
        } else stopLogoAnim()
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..8 -> "早上好"
            in 9..11 -> "上午好"
            in 12..13 -> "中午好"
            in 14..18 -> "下午好"
            in 19..22 -> "晚上好"
            else -> "夜深了"
        }
    }

    /** 手表/紧凑屏：隐藏搜索栏、快捷指令、欢迎建议词；超窄屏再隐藏副标题 */
    private fun applyCompactMode() {
        val w = isWatch
        findViewById<View>(R.id.searchBar).visibility = if (w) View.GONE else View.VISIBLE
        quickRow.visibility = if (w) View.GONE else View.VISIBLE
        for (id in intArrayOf(R.id.sug1, R.id.sug2, R.id.sug3, R.id.sug4)) {
            findViewById<View>(id).visibility = if (w) View.GONE else View.VISIBLE
        }
        // 最窄屏 (<240dp)：连副标题也别显示，避免顶栏被挤爆
        val veryNarrow = resources.configuration.smallestScreenWidthDp < 240
        subtitleView.visibility = if (veryNarrow) View.GONE else View.VISIBLE
    }

    private fun applyToolToggles() {
        val d = resources.displayMetrics.density
        val scale = Prefs.uiScale / 100f
        fun style(v: TextView, on: Boolean) {
            v.background = if (on)
                Ui.roundedGradient(theme.primary, theme.accent, 16f * d)
            else
                Ui.panel(theme.surface2, 16f * d, Ui.withAlpha(theme.dim, 90), 1f * d)
            v.setTextColor(if (on) Color.WHITE else theme.dim)
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, spRes(R.dimen.chip_size) * scale)
            v.elevation = if (on) 2f * d else 0f
        }
        style(btnToggleDeep, Prefs.deepThink)
        style(btnToggleWeb, Prefs.webSearch)
    }

    private fun onToggleCapability(kind: String) {
        val isDeep = kind == "deep"
        val newVal = if (isDeep) !Prefs.deepThink else !Prefs.webSearch
        if (isDeep) Prefs.deepThink = newVal else Prefs.webSearch = newVal
        applyToolToggles()
        if (!newVal) {
            if (isDeep) {
                val cfg = currentConfigSilent()
                val cap = cfg?.let { Prefs.getCap(Prefs.provider, it.model) }
                if (cap?.deep == CapResult.DEEP_AUTO && !cap.deepCloseable) {
                    toast("该模型始终深度思考，无法通过开关关闭（可点思考标题折叠隐藏）")
                }
            }
            return
        }
        val cfg = currentConfigSilent()
        if (cfg == null) { toast("请先在设置里配置模型"); return }
        probeCapability(cfg, isDeep)
    }

    private fun probeCapability(cfg: ApiConfig, isDeep: Boolean) {
        val cap = Prefs.getCap(Prefs.provider, cfg.model)
        if (cap != null) {
            applyCapToToggle(cap, isDeep)
            return
        }
        toast("正在检测模型能力…")
        ApiClient.probeCapabilities(cfg,
            onResult = { result -> runOnUiThread {
                Prefs.setCap(Prefs.provider, cfg.model, result)
                applyCapToToggle(result, isDeep)
            } },
            onError = { e -> runOnUiThread {
                toast("能力检测失败（$e），开关保持开启，若不生效请关闭")
            } })
    }

    private fun applyCapToToggle(cap: CapResult, isDeep: Boolean) {
        if (isDeep) {
            when (cap.deep) {
                CapResult.DEEP_NONE -> {
                    Prefs.deepThink = false; applyToolToggles()
                    toast("实测该模型不输出思考过程，深度思考已自动关闭")
                }
                CapResult.DEEP_PARAM -> toast("已开启深度思考（实测支持）")
                else -> if (cap.deepCloseable) toast("已开启：该模型自带深度思考")
                    else toast("已开启：该模型自带深度思考，无法关闭（可折叠隐藏思考内容）")
            }
        } else {
            when (cap.web) {
                CapResult.WEB_NO -> {
                    Prefs.webSearch = false; applyToolToggles()
                    toast("实测该模型无法联网搜索，已自动关闭")
                }
                CapResult.WEB_YES -> toast("已开启联网搜索（实测支持）")
                else -> toast("已开启联网搜索（实测未能完全确认，若失败请关闭）")
            }
        }
    }

    private fun spRes(id: Int): Float = resources.getDimension(id) / resources.displayMetrics.density

    private fun updateModelSubtitle() {
        val label = PROVIDER_LABELS[Prefs.provider] ?: Prefs.provider
        val model = when {
            Prefs.provider == "zhipu_free" -> "glm-4-flash"
            else -> Prefs.modelNameOf(Prefs.provider).ifBlank { "未配置" }
        }
        subtitleView.text = "$label · $model"
    }

    private fun confirmNewChat() {
        if (displayMessages.isEmpty()) { toast("当前没有聊天记录"); return }
        AlertDialog.Builder(this)
            .setTitle("开始新对话")
            .setMessage("将清空当前所有聊天记录，确定吗？")
            .setPositiveButton("清空") { _, _ ->
                displayMessages.clear()
                adapter.setMessages(emptyList())
                ChatStore.clear()
                updateEmptyState()
                toast("已开始新对话")
            }
            .setNegativeButton("取消", null)
            .show()
            .also { dlg ->
                dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.primary)
                dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.primary)
            }
    }

    // ---------------- 附件 ----------------

    private fun handleAttachUri(uri: Uri) {
        val name = queryName(uri) ?: "file"
        val size = uriSize(uri)
        val mime = contentResolver.getType(uri).orEmpty()
        val textLike = FileTypes.isText(name, mime)
        val isImage = FileTypes.isImageMime(mime)
        if (size > MAX_FILE_SIZE) { toast("文件超过 1 GB，请压缩后重试"); return }
        if (!textLike && !isImage && size > 25L * 1024 * 1024) {
            toast("非文本/图片文件超过 25 MB，暂不支持")
            return
        }

        try {
            pendingAttachment = readAttachment(uri, name, size, mime, textLike, isImage)
            renderAttachment()
            toast("已添加：$name")
        } catch (e: Exception) {
            toast("文件读取失败：${e.message}")
        }
    }

    private fun readAttachment(
        uri: Uri, name: String, size: Long, mime: String, textLike: Boolean, isImage: Boolean
    ): PendingAttachment {
        return when {
            textLike -> {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                // 关键：不再默认按 UTF-8 解码，按 BOM → 严格 UTF-8 → GB18030 → GBK → 兜底 UTF-8 逐级尝试，
                // 解决中文 GBK 编码的 txt 被读成乱码的根因
                val text = FileTypes.decodeText(bytes) ?: "(二进制内容，已转 Base64 编码)"
                val truncated = if (text.length > MAX_TEXT_CHARS) {
                    text.substring(0, MAX_TEXT_CHARS) + "\n…（文本过长，已截断）"
                } else text
                PendingAttachment(name, "text", size, mime, truncated)
            }
            isImage -> {
                val bmp = decodeSampled(uri) ?: throw Exception("图片解码失败")
                val resized = resizeMax(bmp, 1024)
                val out = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, 80, out)
                val b64 = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
                PendingAttachment(name, "image", size, mime.ifEmpty { "image/jpeg" }, "data:image/jpeg;base64,$b64")
            }
            else -> {
                val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                val truncated = if (raw.size > MAX_BINARY_BYTES) {
                    // 超大二进制：只取前 MAX_BINARY_BYTES 编码，防止请求体过大
                    raw.copyOfRange(0, MAX_BINARY_BYTES.toInt())
                } else raw
                val b64 = android.util.Base64.encodeToString(truncated, android.util.Base64.NO_WRAP)
                val note = if (raw.size > MAX_BINARY_BYTES) {
                    "\n\n…（文件过大，仅编码前 ${FileTypes.sizeText(MAX_BINARY_BYTES)} 内容）"
                } else ""
                PendingAttachment(name, "binary", size, mime, b64 + note)
            }
        }
    }

    private fun decodeSampled(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        } catch (_: Exception) { return null }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return try {
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (_: Exception) { null }
    }

    private fun resizeMax(bmp: Bitmap, max: Int): Bitmap {
        val w = bmp.width; val h = bmp.height
        if (w <= max && h <= max) return bmp
        val ratio = minOf(max.toFloat() / w, max.toFloat() / h)
        return Bitmap.createScaledBitmap(bmp, (w * ratio).roundToInt(), (h * ratio).roundToInt(), true)
    }

    private fun queryName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
        }
        return name
    }

    private fun uriSize(uri: Uri): Long = try {
        contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
    } catch (_: Exception) { 0L }

    private fun renderAttachment() {
        val pa = pendingAttachment
        if (pa == null) { attachmentBar.visibility = View.GONE; return }
        attachmentBar.visibility = View.VISIBLE
        attIcon.text = FileTypes.typeBadge(pa.type)
        attName.text = pa.name
        val size = FileTypes.sizeText(pa.size)
        val mime = pa.mime.ifEmpty { when (pa.type) { "image" -> "image"; "text" -> "text"; else -> "binary" } }
        attMeta.text = "${FileTypes.typeLabel(pa.type)} · $mime${if (size.isNotEmpty()) " · $size" else ""}"
    }

    // ---------------- 语音 / 朗读 ----------------

    private fun onMicDown() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startVoice()
    }

    private fun startVoice() {
        if (!SpeechHelper.available(this)) {
            // 系统根本没语音服务：直接弹系统语音界面
            if (!launchSystemVoice()) toast("此设备没有可用的语音识别服务")
            return
        }
        try {
            speech.start()
        } catch (e: Exception) {
            // 启动瞬间崩溃时也尝试系统回退
            if (!launchSystemVoice()) toast("语音启动失败，请改用文字输入")
        }
    }

    /** 调起系统语音识别界面（手表 / 旧版 Android 必备的回退） */
    private fun launchSystemVoice(): Boolean = try {
        val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, SpeechHelper.pickLanguage())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, SpeechHelper.pickLanguage())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "请说话")
        }
        voiceLauncher.launch(it)
        true
    } catch (_: Exception) {
        false
    }

    private fun speak(text: String) {
        val t = tts ?: return
        val clean = text.replace(Regex("[*`#_~>|\\[\\]\\(\\)]"), " ").replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "tts_${System.currentTimeMillis()}")
    }

    // ---------------- 其它 ----------------

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("chat", text))
        toast("已复制")
    }

    private fun scrollBottom() {
        rv.post { if (adapter.itemCount > 0) rv.scrollToPosition(adapter.itemCount - 1) }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun now(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    private fun showPrivacy() {
        val dlg = AlertDialog.Builder(this)
            .setTitle("隐私与安全")
            .setMessage(
                "本软件为纯本地应用，无需联网即可运行（AI 对话除外）。\n\n" +
                    "• 所有数据（聊天记录、配置、上传文件）仅保存在设备本地\n" +
                    "• 不会上传、收集或泄露您的个人信息\n" +
                    "• AI 对话仅用于即时交流，不留存云端\n" +
                    "• 开源透明，无后台进程\n\n继续使用即表示您同意上述条款。"
            )
            .setCancelable(false)
            .setPositiveButton("我已知晓并同意") { _, _ -> Prefs.privacyAgreed = true }
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.primary)
    }

    // ---------------- 主题 / 美化 ----------------

    private fun applyTheme() {
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        theme = Themes.byKey(Prefs.theme, dark)
        val scale = Prefs.uiScale / 100f
        // 手表小屏再额外压一档字号，确保输入框和气泡不被撑爆
        val watchScale = if (isWatch) 0.9f else 1f
        adapter.theme = theme
        adapter.fontSize = (Prefs.fontSize * scale * watchScale).roundToInt().coerceAtLeast(10)
        adapter.notifyDataSetChanged()

        val d = resources.displayMetrics.density
        val topTint = Ui.blend(theme.bg, theme.primary, if (theme.isDark) 0.12f else 0.06f)
        root.background = Ui.vGradient(topTint, theme.bg)
        applyBg()

        titleView.setTextColor(theme.text)
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, spRes(R.dimen.title_size) * scale)
        titleView.post {
            val p = titleView.paint
            p.shader = LinearGradient(0f, 0f, p.measureText(titleView.text.toString()), 0f,
                theme.primary, theme.accent, Shader.TileMode.CLAMP)
        }
        subtitleView.setTextColor(theme.dim)
        subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, spRes(R.dimen.subtitle_size) * scale)

        findViewById<View>(R.id.topBar).background = Ui.vGradient(
            Ui.withAlpha(theme.surface, 200), Ui.withAlpha(theme.surface, 0))

        findViewById<View>(R.id.searchBar).background = Ui.panel(
            theme.surface, 22f * d, Ui.withAlpha(theme.dim, 60), 1f * d)
        searchInput.setTextColor(theme.text)
        searchInput.setHintTextColor(theme.dim)
        if (Build.VERSION.SDK_INT >= 23) {
            searchInput.compoundDrawableTintList = ColorStateList.valueOf(theme.dim)
        }
        searchCount.setTextColor(theme.dim)

        inputZone.background = Ui.panel(
            theme.surface, 22f * d, Ui.withAlpha(theme.primary, if (theme.isDark) 70 else 55), 1.5f * d)
        inputZone.elevation = 4f * d
        input.setTextColor(theme.text)
        input.setHintTextColor(theme.dim)
        input.textSize = Prefs.fontSize * scale * watchScale
        attName.setTextColor(theme.text)
        attMeta.setTextColor(theme.dim)

        btnSend.background = Ui.circleGradient(theme.primary, theme.accent)
        btnSend.elevation = 3f * d
        if (!generating) btnSend.setColorFilter(Color.WHITE)
        btnAttach.setColorFilter(theme.primary)
        btnMic.setColorFilter(theme.primary)
        btnSearchClear.setColorFilter(theme.dim)
        findViewById<ImageButton>(R.id.btnSettings).setColorFilter(theme.text)
        findViewById<ImageButton>(R.id.btnNewChat).setColorFilter(theme.text)
        findViewById<ImageButton>(R.id.btnAttRemove).setColorFilter(theme.dim)

        btnScrollDown.background = Ui.panel(
            theme.surface, 19f * d, Ui.withAlpha(theme.primary, 80), 1f * d)
        btnScrollDown.setColorFilter(theme.text)
        btnScrollDown.elevation = 6f * d

        applyToolToggles()

        // 附件小卡片：圆角 + 细描边
        attachmentBar.background = Ui.card(
            theme.surface, 16f * d, theme.border, 1f * d)
        attachmentBar.setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
        attIcon.background = Ui.circleGradient(theme.primary, theme.accent)
        attIcon.setTextColor(Color.WHITE)

        // 快捷指令 chips：渐变描边胶囊（quickRow 是 HorizontalScrollView，内层 LinearLayout 才是 chip 容器）
        val chipContainer = (quickRow as? ViewGroup)?.getChildAt(0) as? ViewGroup
        if (chipContainer != null) {
            for (i in 0 until chipContainer.childCount) {
                val v = chipContainer.getChildAt(i) as? TextView ?: continue
                v.setTextColor(theme.text)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 16f * d
                    setColor(theme.surface2)
                    setStroke((1f * d).toInt(), Ui.withAlpha(theme.primary, 100))
                }
                v.setTextSize(TypedValue.COMPLEX_UNIT_SP, spRes(R.dimen.chip_size) * scale)
                v.elevation = 1f * d
            }
        }

        logo.background = Ui.circleGradient(theme.primary, theme.accent)
        findViewById<View>(R.id.logoHalo).background = Ui.circle(Ui.withAlpha(theme.primary, 42))
        topLogo.apply {
            background = Ui.circleGradient(theme.primary, theme.accent)
            setTextColor(Color.WHITE)
            textSize = spRes(R.dimen.avatar_text) * 0.7f
            elevation = 2f * d
        }
        emptyTitle.setTextColor(theme.text)
        emptySub.setTextColor(theme.dim)
        for (i in 0 until 4) {
            val container = findViewById<View>(intArrayOf(R.id.sug1, R.id.sug2, R.id.sug3, R.id.sug4)[i])
            container.background = Ui.panel(
                theme.surface, 18f * d, Ui.withAlpha(theme.primary, 70), 1f * d)
            container.elevation = 1f * d
            findViewById<TextView>(intArrayOf(R.id.sugText1, R.id.sugText2, R.id.sugText3, R.id.sugText4)[i]).apply {
                setTextColor(theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, spRes(R.dimen.sug_size) * scale)
            }
            findViewById<View>(intArrayOf(R.id.sugBar1, R.id.sugBar2, R.id.sugBar3, R.id.sugBar4)[i])
                .background = Ui.round(theme.primary, 3f * d)
        }
        btnMic.background = Ui.circle(Ui.withAlpha(theme.primary, 26))
        btnAttach.background = Ui.circle(Ui.withAlpha(theme.primary, 26))

        val flags = window.decorView.systemUiVisibility
        window.decorView.systemUiVisibility =
            if (theme.isDark) flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            else flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    private fun startLogoAnim() {
        if (logoAnimX != null) return
        logoAnimX = ObjectAnimator.ofFloat(logo, View.SCALE_X, 1f, 1.1f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            start()
        }
        logoAnimY = ObjectAnimator.ofFloat(logo, View.SCALE_Y, 1f, 1.1f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun stopLogoAnim() {
        logoAnimX?.cancel(); logoAnimY?.cancel()
        logoAnimX = null; logoAnimY = null
        logo.scaleX = 1f; logo.scaleY = 1f
    }

    private fun applyBg() {
        val path = Prefs.bgImage
        if (path.isNotEmpty()) {
            val bmp = BitmapFactory.decodeFile(path)
            if (bmp != null) {
                bgImage.visibility = View.VISIBLE
                bgImage.setImageBitmap(bmp)
                bgImage.setColorFilter(Color.argb(70, 0, 0, 0))
            } else bgImage.visibility = View.GONE
        } else bgImage.visibility = View.GONE
    }
}