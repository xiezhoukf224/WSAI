package xie.wsai.top

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "wanshang_ai"
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        }
    }

    private fun s(key: String, def: String) = sp.getString(key, def) ?: def

    var theme: String get() = s("app_theme", "auto"); set(v) = put("app_theme", v)
    var bgImage: String get() = s("custom_bg_img", ""); set(v) = put("custom_bg_img", v)
    var uiScale: Int get() = sp.getInt("ui_scale", 100); set(v) = put("ui_scale", v)
    var fontSize: Int get() = sp.getInt("font_size", 14); set(v) = put("font_size", v)
    var systemPrompt: String get() = s("system_prompt", ""); set(v) = put("system_prompt", v)
    var provider: String get() = s("provider", "zhipu_free"); set(v) = put("provider", v)
    var baseUrl: String get() = s("base_url", ""); set(v) = put("base_url", v)
    fun baseUrlOf(provider: String): String = s("base_url_$provider", "")
    fun setBaseUrlOf(provider: String, v: String) = put("base_url_$provider", v)
    var modelName: String get() = s("model_name", ""); set(v) = put("model_name", v)
    fun modelNameOf(provider: String): String = s("model_name_$provider", "")
    fun setModelNameOf(provider: String, v: String) = put("model_name_$provider", v)
    var deepThink: Boolean get() = sp.getBoolean("deep_think", false); set(v) = put("deep_think", v)
    var webSearch: Boolean get() = sp.getBoolean("web_search", false); set(v) = put("web_search", v)
    var privacyAgreed: Boolean get() = sp.getBoolean("privacy_agreed", false); set(v) = put("privacy_agreed", v)

    /** 流式输出节流间隔（毫秒）：数值越小越顺滑，越大越省电（手表上默认更省） */
    var streamThrottleMs: Int get() = sp.getInt("stream_throttle", 40); set(v) = put("stream_throttle", v)

    fun apiKey(provider: String): String = s("api_key_$provider", "")
    fun setApiKey(provider: String, v: String) = put("api_key_$provider", v)

    /** 模型能力探测结果缓存（按 提供商+模型名 存储，JSON 格式） */
    fun getCap(provider: String, model: String): CapResult? {
        val raw = s("cap_${provider}_$model", "")
        if (raw.isEmpty()) return null
        return try {
            val o = org.json.JSONObject(raw)
            CapResult(
                o.optInt("deep", CapResult.DEEP_NONE),
                o.optString("deepParam", "").ifEmpty { null },
                o.optBoolean("deepCloseable", false),
                o.optInt("web", CapResult.WEB_UNKNOWN)
            )
        } catch (_: Exception) { null }
    }
    fun setCap(provider: String, model: String, cap: CapResult) {
        val o = org.json.JSONObject()
        o.put("deep", cap.deep)
        o.put("deepParam", cap.deepParam ?: "")
        o.put("deepCloseable", cap.deepCloseable)
        o.put("web", cap.web)
        put("cap_${provider}_$model", o.toString())
    }

    fun clearBg() = sp.edit().remove("custom_bg_img").apply()

    /** 恢复默认设置：清掉所有配置，但保留隐私协议标记，避免重新弹窗 */
    fun resetAll() {
        val e = sp.edit()
        for (k in sp.all.keys) if (k != "privacy_agreed") e.remove(k)
        e.apply()
    }

    private fun put(key: String, value: Any) {
        val e = sp.edit()
        when (value) {
            is String -> e.putString(key, value)
            is Boolean -> e.putBoolean(key, value)
            is Int -> e.putInt(key, value)
            is Long -> e.putLong(key, value)
        }
        e.apply()
    }
}
