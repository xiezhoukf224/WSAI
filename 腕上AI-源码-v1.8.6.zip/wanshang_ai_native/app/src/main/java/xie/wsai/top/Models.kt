package xie.wsai.top

/** 附件元信息（用于聊天气泡里的文件小卡片，不参与发给 AI 的正文） */
data class Attachment(val name: String, val type: String, val size: Long)

data class ChatMessage(
    val role: String, // "user" | "assistant" | "system"
    var content: String,
    val time: String,
    val attachments: List<Attachment> = emptyList(),
    var reasoning: String = "", // 深度思考过程（AI 专用，可折叠）
    var expectingReasoning: Boolean = false, // 本次请求是否真的会返回思考（用于控制"思考中"动画）
    /**
     * 本次用户消息实际发给 AI 的完整内容（含附件正文）。
     * 用于「重新生成」时还原请求，界面上只显示 content + 附件卡片，不会被 base64 正文撑爆。
     */
    var apiContent: String = ""
)

/**
 * 模型能力探测结果（证据驱动，不靠模型名猜）
 * deep: 0=不支持  1=带参数可开启思考  2=模型自带思考（开关关不掉，只能用参数尝试关闭）
 * deepParam: deep==1 时开启思考的参数名；deep==2 且 deepCloseable 时是关闭思考的参数名
 * deepCloseable: deep==2 时，能否用参数关闭自带思考
 * web: 0=不支持  1=支持  2=无法确认
 */
data class CapResult(
    val deep: Int,
    val deepParam: String?,
    val deepCloseable: Boolean,
    val web: Int
) {
    companion object {
        const val DEEP_NONE = 0
        const val DEEP_PARAM = 1
        const val DEEP_AUTO = 2
        const val WEB_NO = 0
        const val WEB_YES = 1
        const val WEB_UNKNOWN = 2
    }
}
