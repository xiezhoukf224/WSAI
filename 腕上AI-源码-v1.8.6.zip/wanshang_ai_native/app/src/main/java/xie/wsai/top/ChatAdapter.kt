package xie.wsai.top

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.BackgroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(
    private val onCopy: (String) -> Unit,
    private val onRedo: () -> Unit,
    private val onTts: (String) -> Unit,
    private val onLongPress: (ChatMessage) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val all = mutableListOf<Any>()
    private val shown = mutableListOf<Any>()
    private var query = ""
    var theme: Theme = Themes.cyber
    var fontSize: Int = 14

    /** 流式输出时追加在文末的光标（纯文本符号，非 emoji） */
    private val cursor = " ▍"

    // 流式生成中的消息
    private var streaming: ChatMessage? = null
    private var streamingAutoExpand = false
    // 当前绑定流式消息的 holder（用于局部更新，避免整项重绘导致的抖动）
    private var streamingHolder: AiVH? = null
    // 新插入消息的进入动画标记
    private var animateNext = false

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_AI = 1
        private const val TYPE_SYSTEM = 2
    }

    fun setMessages(list: List<ChatMessage>) { all.clear(); all.addAll(list); rebuild() }
    fun append(msg: ChatMessage) { all.add(msg); animateNext = true; rebuild() }
    fun appendSystem(text: String, time: String = "") {
        all.add(ChatMessage("system", text, time, emptyList())); rebuild()
    }
    fun remove(m: ChatMessage) { val i = all.indexOfFirst { it === m }; if (i >= 0) { all.removeAt(i); rebuild() } }
    fun removeLastAi() {
        val i = all.indexOfLast { it is ChatMessage && it.role == "assistant" }
        if (i >= 0) { all.removeAt(i); rebuild() }
    }

    // ---------- 流式 ----------
    fun startStreaming(m: ChatMessage) {
        streaming = m
        streamingAutoExpand = true
        all.add(m)
        animateNext = true
        rebuild()
    }

    /** 流式增量刷新：优先直接更新已绑定的 holder，避免 notifyItemChanged 全量重绘造成抖动 */
    fun updateStreaming() {
        val m = streaming ?: return
        val h = streamingHolder
        if (h != null && h.bound === m) {
            h.updateLive(m)
        } else {
            val idx = shown.indexOfFirst { it === m }
            if (idx >= 0) notifyItemChanged(idx)
        }
    }

    fun finishStreaming() {
        val m = streaming
        streaming = null
        streamingAutoExpand = false
        streamingHolder = null
        if (m != null) {
            val idx = shown.indexOfFirst { it === m }
            if (idx >= 0) notifyItemChanged(idx)
        }
    }

    fun isStreaming(): Boolean = streaming != null

    fun setQuery(q: String) { query = q; rebuild() }
    fun matchCount(): Int =
        if (query.isEmpty()) 0
        else all.count { it is ChatMessage && it.role != "system" && it.content.lowercase().contains(query.lowercase()) }

    private fun rebuild() {
        shown.clear()
        if (query.isEmpty()) shown.addAll(all)
        else {
            val q = query.lowercase()
            for (it in all) when (it) {
                is ChatMessage -> if (it.role == "system" || it.content.lowercase().contains(q)) shown.add(it)
            }
        }
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (val it = shown[position]) {
        is ChatMessage -> when (it.role) { "user" -> TYPE_USER; "assistant" -> TYPE_AI; else -> TYPE_SYSTEM }
        else -> TYPE_SYSTEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_USER -> UserVH(inf.inflate(R.layout.item_user, parent, false))
            TYPE_AI -> AiVH(inf.inflate(R.layout.item_ai, parent, false))
            else -> SystemVH(inf.inflate(R.layout.item_system, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is UserVH -> holder.bind(shown[position] as ChatMessage, position)
            is AiVH -> holder.bind(shown[position] as ChatMessage, position)
            is SystemVH -> holder.bind(shown[position] as ChatMessage)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is AiVH) {
            holder.stopDots()
            if (holder === streamingHolder) streamingHolder = null
        }
    }

    override fun getItemCount(): Int = shown.size

    private fun density(v: View) = v.context.resources.displayMetrics.density

    /** 附件小卡片文案：类型 + 文件名 + 大小（纯文字，不含 emoji，也不展示正文） */
    private fun attachText(m: ChatMessage): String =
        m.attachments.joinToString("\n") { att ->
            val size = FileTypes.sizeText(att.size)
            val meta = listOf(FileTypes.typeLabel(att.type), size).filter { it.isNotEmpty() }.joinToString(" · ")
            "${att.name}\n$meta"
        }

    private fun avatarDrawable(): android.graphics.drawable.GradientDrawable =
        Ui.circleGradient(theme.primary, theme.accent)

    /** 搜索命中高亮：在渲染好的 Spanned 上按原文位置叠加背景色 */
    private fun highlight(src: Spanned): Spanned {
        val q = query
        if (q.isEmpty()) return src
        val text = src.toString()
        val lower = text.lowercase()
        val ql = q.lowercase()
        val sb = SpannableStringBuilder(src)
        var idx = 0
        while (true) {
            val i = lower.indexOf(ql, idx)
            if (i < 0) break
            sb.setSpan(
                BackgroundColorSpan(Ui.withAlpha(theme.primary, 80)),
                i, i + q.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            idx = i + q.length
        }
        return sb
    }

    private fun renderContent(m: ChatMessage): Spanned =
        highlight(Markdown.render(m.content, theme.surface2, theme.dim, theme.primary))

    /** 新消息淡入上移动画（只在真正插入新消息时触发，流式刷新不触发） */
    private fun animateIn(v: View, position: Int) {
        if (!animateNext || position != itemCount - 1) return
        animateNext = false
        v.alpha = 0f
        v.translationY = 20f * density(v)
        v.animate().alpha(1f).translationY(0f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    inner class UserVH(v: View) : RecyclerView.ViewHolder(v) {
        private val content: TextView = v.findViewById(R.id.content)
        private val time: TextView = v.findViewById(R.id.time)
        private val attach: TextView = v.findViewById(R.id.attach)

        fun bind(m: ChatMessage, position: Int) {
            val d = density(itemView)
            content.text = renderContent(m)
            content.movementMethod = LinkMovementMethod.getInstance()
            content.background = Ui.bubbleGradient(theme.primary, theme.accent, 18f * d, "br", 6f * d)
            content.setTextColor(Color.WHITE)
            content.textSize = fontSize.toFloat()
            content.elevation = 2f * d
            time.text = m.time
            time.setTextColor(theme.dim)

            val at = attachText(m)
            attach.visibility = if (at.isEmpty()) View.GONE else View.VISIBLE
            if (at.isNotEmpty()) {
                attach.text = at
                attach.setTextColor(Color.WHITE)
                attach.background = Ui.card(
                    Ui.withAlpha(Color.WHITE, 38), 12f * d, Ui.withAlpha(Color.WHITE, 90), 1f * d)
                attach.setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            }
            itemView.setOnLongClickListener { onLongPress(m); true }
            animateIn(itemView, position)
        }
    }

    inner class AiVH(v: View) : RecyclerView.ViewHolder(v) {
        private val avatar: TextView = v.findViewById(R.id.avatar)
        private val content: TextView = v.findViewById(R.id.content)
        private val time: TextView = v.findViewById(R.id.time)
        private val attach: TextView = v.findViewById(R.id.attach)
        private val reasoningHeader: TextView = v.findViewById(R.id.reasoningHeader)
        private val reasoning: TextView = v.findViewById(R.id.reasoning)
        private val thinkingRow: LinearLayout = v.findViewById(R.id.thinkingRow)
        private val thinkLabel: TextView = v.findViewById(R.id.thinkLabel)
        private val thinkDot1: View = v.findViewById(R.id.thinkDot1)
        private val thinkDot2: View = v.findViewById(R.id.thinkDot2)
        private val thinkDot3: View = v.findViewById(R.id.thinkDot3)
        private val copy: ImageButton = v.findViewById(R.id.btnCopy)
        private val redo: ImageButton = v.findViewById(R.id.btnRedo)
        private val tts: ImageButton = v.findViewById(R.id.btnTts)

        private var reasoningOpen = false
        private var dotsRunning = false
        private val dotAnims = mutableListOf<ObjectAnimator>()

        /** 当前绑定的消息（用于流式局部更新的身份校验） */
        var bound: ChatMessage? = null
            private set

        fun bind(m: ChatMessage, position: Int) {
            bound = m
            val d = density(itemView)

            avatar.background = avatarDrawable().apply {
                setStroke((1.5f * d).toInt(), Ui.withAlpha(Color.WHITE, 70))
            }
            content.background = Ui.bubble(theme.surface, 18f * d, "tl", 6f * d).apply {
                setStroke((1f * d).toInt(), theme.border)
            }
            content.setTextColor(theme.text)
            content.textSize = fontSize.toFloat()
            content.elevation = 1.5f * d
            content.movementMethod = LinkMovementMethod.getInstance()
            time.text = m.time
            time.setTextColor(theme.dim)

            val at = attachText(m)
            attach.visibility = if (at.isEmpty()) View.GONE else View.VISIBLE
            if (at.isNotEmpty()) {
                attach.text = at
                attach.setTextColor(theme.text)
                attach.background = Ui.card(theme.surface2, 12f * d, theme.border, 1f * d)
                attach.setPadding((10 * d).toInt(), (7 * d).toInt(), (10 * d).toInt(), (7 * d).toInt())
            }

            reasoning.background = Ui.panel(theme.surface2, 12f * d, Color.TRANSPARENT, 0f)
            reasoning.setTextColor(theme.dim)
            reasoningHeader.setTextColor(theme.primary)
            thinkLabel.setTextColor(theme.dim)
            reasoningHeader.setOnClickListener {
                if (m === streaming && streamingAutoExpand) streamingAutoExpand = false
                reasoningOpen = !reasoningOpen
                refreshReasoning(m, m === streaming)
            }

            copy.setColorFilter(theme.dim)
            redo.setColorFilter(theme.dim)
            tts.setColorFilter(theme.dim)
            copy.setOnClickListener { onCopy(m.content) }
            redo.setOnClickListener { onRedo() }
            tts.setOnClickListener { onTts(m.content) }
            itemView.setOnLongClickListener { onLongPress(m); true }

            if (m === streaming) streamingHolder = this
            animateIn(itemView, position)
            updateLive(m)
        }

        /** 流式增量更新：只改文本与状态，不重建背景/动画，避免抖动 */
        fun updateLive(m: ChatMessage) {
            val isStream = m === streaming
            val hasReasoning = m.reasoning.isNotBlank()

            // 思考中动画：仅在「确实期待思考」且还没输出回答时显示，避免不支持思考的模型闪现
            val showThinking = isStream && !hasReasoning && m.content.isBlank() && m.expectingReasoning
            if (showThinking) {
                thinkingRow.visibility = View.VISIBLE
                if (!dotsRunning) startDots()
            } else {
                thinkingRow.visibility = View.GONE
                stopDots()
            }

            if (hasReasoning) {
                reasoningHeader.visibility = View.VISIBLE
                reasoning.text = m.reasoning
                refreshReasoning(m, isStream)
            } else {
                reasoningHeader.visibility = View.GONE
                reasoning.visibility = View.GONE
            }

            // 流式中用纯文本（Markdown 未完整，全量渲染会卡），文末带静态光标；
            // 光标不做逐帧闪烁，避免每秒几十次整段文本重排导致的卡顿
            if (isStream) {
                content.text = if (m.content.isNotBlank()) m.content + cursor else ""
            } else {
                content.text = if (m.content.isNotBlank()) renderContent(m) else ""
            }
        }

        private fun refreshReasoning(m: ChatMessage, isStream: Boolean) {
            val forceOpen = isStream && streamingAutoExpand && m.reasoning.isNotBlank()
            val visible = reasoningOpen || forceOpen
            reasoning.visibility = if (visible) View.VISIBLE else View.GONE
            reasoningHeader.text = if (visible) "深度思考 · 收起" else "深度思考 · 展开"
        }

        private fun startDots() {
            if (dotsRunning) return
            dotsRunning = true
            val dots = listOf(thinkDot1, thinkDot2, thinkDot3)
            dots.forEachIndexed { i, dot ->
                dot.background = Ui.circle(theme.primary)
                dot.alpha = 0.35f
                dot.scaleX = 0.5f
                dot.scaleY = 0.5f
                val sx = ObjectAnimator.ofFloat(dot, View.SCALE_X, 0.5f, 1f).apply {
                    duration = 700; startDelay = i * 140L
                    repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                }
                val sy = ObjectAnimator.ofFloat(dot, View.SCALE_Y, 0.5f, 1f).apply {
                    duration = 700; startDelay = i * 140L
                    repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                }
                val al = ObjectAnimator.ofFloat(dot, View.ALPHA, 0.35f, 1f).apply {
                    duration = 700; startDelay = i * 140L
                    repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                }
                sx.start(); sy.start(); al.start()
                dotAnims.add(sx); dotAnims.add(sy); dotAnims.add(al)
            }
        }

        fun stopDots() {
            dotAnims.forEach { it.cancel() }
            dotAnims.clear()
            dotsRunning = false
        }
    }

    inner class SystemVH(v: View) : RecyclerView.ViewHolder(v) {
        private val content: TextView = v.findViewById(R.id.content)
        fun bind(m: ChatMessage) {
            val d = density(itemView)
            content.text = m.content
            content.setTextColor(theme.dim)
            content.textSize = fontSize.toFloat()
            content.background = Ui.panel(
                Ui.withAlpha(theme.surface2, 210), 14f * d, Ui.withAlpha(theme.dim, 40), 1f * d
            )
            content.setPadding((14 * d).toInt(), (7 * d).toInt(), (14 * d).toInt(), (7 * d).toInt())
        }
    }
}
