package xie.wsai.top

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View

object Ui {
    fun lighten(color: Int, f: Float): Int {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return Color.rgb((r + (255 - r) * f).toInt(), (g + (255 - g) * f).toInt(), (b + (255 - b) * f).toInt())
    }

    fun darken(color: Int, f: Float): Int {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return Color.rgb((r * (1 - f)).toInt(), (g * (1 - f)).toInt(), (b * (1 - f)).toInt())
    }

    fun blend(c1: Int, c2: Int, f: Float): Int =
        Color.rgb(
            (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * f).toInt(),
            (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * f).toInt(),
            (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * f).toInt()
        )

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun round(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = radiusPx; setColor(color) }

    /** 渐变圆角矩形（胶囊开关等） */
    fun roundedGradient(c1: Int, c2: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
        }

    /** 圆角面板：背景色 + 描边，用于输入框 / 搜索栏等 */
    fun panel(color: Int, radiusPx: Float, strokeColor: Int, strokeWidthPx: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(color)
            if (strokeWidthPx > 0 && strokeColor != Color.TRANSPARENT) setStroke(strokeWidthPx.toInt(), strokeColor)
        }

    /** 纯色聊天气泡，指定某个角用小圆角（更真实的聊天气泡感） */
    fun bubble(color: Int, radius: Float, smallCorner: String, smallRadius: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = cornerArray(radius, smallCorner, smallRadius)
            setColor(color)
        }

    /** 渐变聊天气泡 */
    fun bubbleGradient(c1: Int, c2: Int, radius: Float, smallCorner: String, smallRadius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = cornerArray(radius, smallCorner, smallRadius)
        }

    /** 附件小卡片：圆角面板 + 细描边 */
    fun card(color: Int, radiusPx: Float, strokeColor: Int, strokeWidthPx: Float): GradientDrawable =
        panel(color, radiusPx, strokeColor, strokeWidthPx)

    private fun cornerArray(radius: Float, smallCorner: String, smallRadius: Float): FloatArray {
        val a = radius
        val b = smallRadius
        return when (smallCorner) {
            "tl" -> floatArrayOf(b, b, a, a, a, a, a, a)
            "tr" -> floatArrayOf(a, a, b, b, a, a, a, a)
            "br" -> floatArrayOf(a, a, a, a, b, b, a, a)
            "bl" -> floatArrayOf(a, a, a, a, a, a, b, b)
            else -> floatArrayOf(a, a, a, a, a, a, a, a)
        }
    }

    fun vGradient(c1: Int, c2: Int, radiusPx: Float = 0f): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c1, c2)).apply { cornerRadius = radiusPx }

    fun circleGradient(c1: Int, c2: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { shape = GradientDrawable.OVAL }

    fun circle(color: Int): GradientDrawable =
        GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    /** 按压缩放反馈（丝滑小动效）。注意会占用 OnTouchListener，有触摸监听的控件别用 */
    fun pressScale(view: View) {
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(110).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                }
            }
            false
        }
    }

    /** 按压缩放反馈（不拦截点击事件，用 OnTouchListener 之外的场景） */
    fun pressScaleSafe(view: View) {
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(110).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }
}
