package xie.wsai.top

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object ChatStore {
    private const val KEY = "chat_history"
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("wanshang_ai", Context.MODE_PRIVATE)
        }
    }

    fun save(list: List<ChatMessage>) {
        // 最多保留最近 200 条，防止 SharedPreferences 存储无限膨胀
        val trimmed = if (list.size > 200) list.subList(list.size - 200, list.size) else list
        val arr = JSONArray()
        for (m in trimmed) {
            val o = JSONObject()
            o.put("role", m.role)
            o.put("content", m.content)
            o.put("time", m.time)
            if (m.reasoning.isNotEmpty()) o.put("reasoning", m.reasoning)
            if (m.apiContent.isNotEmpty()) o.put("api", m.apiContent)
            if (m.attachments.isNotEmpty()) {
                val a = JSONArray()
                for (att in m.attachments) {
                    val ao = JSONObject()
                    ao.put("name", att.name)
                    ao.put("type", att.type)
                    ao.put("size", att.size)
                    a.put(ao)
                }
                o.put("attachments", a)
            }
            arr.put(o)
        }
        sp.edit().putString(KEY, arr.toString()).apply()
    }

    fun load(): List<ChatMessage> {
        val s = sp.getString(KEY, null) ?: return emptyList()
        val list = mutableListOf<ChatMessage>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val atts = mutableListOf<Attachment>()
                if (o.has("attachments")) {
                    val a = o.getJSONArray("attachments")
                    for (j in 0 until a.length()) {
                        val ao = a.getJSONObject(j)
                        atts.add(Attachment(ao.getString("name"), ao.getString("type"), ao.getLong("size")))
                    }
                }
                list.add(
                    ChatMessage(
                        o.getString("role"),
                        o.getString("content"),
                        o.optString("time", ""),
                        atts,
                        o.optString("reasoning", ""),
                        false,
                        o.optString("api", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun clear() = sp.edit().remove(KEY).apply()
}
