package xie.wsai.top

/**
 * 文件类型识别 + 文本编码识别
 *
 * 修复「上传文件发给 AI 是一段乱码」的关键：旧代码把任何带扩展名的文件都当 UTF-8 读，
 * GBK/GB18030 编码的中文 txt 读出来必然是乱码，再原样发给模型，模型也只能看到乱码。
 */
object FileTypes {

    /** 文本类扩展名（无 MIME 时兜底判断） */
    private val TEXT_EXT = Regex(
        "\\.(txt|text|log|md|markdown|json|jsonl|xml|html|htm|css|scss|less|js|mjs|cjs|ts|tsx|jsx|vue|svelte|" +
            "py|java|kt|kts|gradle|groovy|scala|go|rs|c|h|cc|cpp|hpp|cs|m|mm|swift|php|rb|pl|pm|lua|dart|r|" +
            "sh|bash|zsh|bat|cmd|ps1|sql|yml|yaml|toml|ini|conf|cfg|properties|env|pro|proguard|gitignore|" +
            "csv|tsv|srt|ass|vtt|tex|patch|diff)$",
        RegexOption.IGNORE_CASE
    )

    /** 明确是二进制的扩展名（避免误当文本读成乱码） */
    private val BINARY_EXT = Regex(
        "\\.(zip|rar|7z|tar|gz|bz2|xz|apk|jar|dex|aar|so|dll|exe|bin|iso|img|mp3|wav|flac|aac|ogg|m4a|amr|" +
            "mp4|mkv|avi|mov|wmv|flv|webm|ttf|otf|woff|woff2|pdf|doc|docx|xls|xlsx|ppt|pptx|db|sqlite)$",
        RegexOption.IGNORE_CASE
    )

    fun isImageMime(mime: String): Boolean = mime.startsWith("image/")

    fun isTextMime(mime: String): Boolean =
        mime.startsWith("text/") ||
            mime.contains("json") || mime.contains("xml") || mime.contains("javascript") ||
            mime.contains("yaml") || mime.contains("x-sh") || mime.contains("x-python") ||
            mime.contains("csv") || mime.contains("markdown")

    fun isBinaryExt(name: String): Boolean = BINARY_EXT.containsMatchIn(name)

    /** 综合 MIME + 扩展名判断是不是文本文件 */
    fun isText(name: String, mime: String): Boolean {
        if (isImageMime(mime)) return false
        if (isBinaryExt(name)) return false
        if (isTextMime(mime)) return true
        return TEXT_EXT.containsMatchIn(name)
    }

    /**
     * 文本解码：BOM → 严格 UTF-8 → GB18030/GBK → 宽松 UTF-8 兜底。
     * 返回 null 表示内容像二进制（解码结果含大量替换符/控制字符），应改走 base64。
     */
    fun decodeText(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return ""
        // 1) BOM
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        // 2) 严格 UTF-8（含中文的合法 UTF-8 一定能解出来）
        strictUtf8(bytes)?.let { return it }
        // 3) 中文常见编码（GBK 是 GB18030 子集，中文 Windows 记事本默认就是它）
        decodeCharset(bytes, "GB18030")?.let { return it }
        decodeCharset(bytes, "GBK")?.let { return it }
        // 4) 宽松 UTF-8 兜底，但内容明显是二进制就放弃
        val loose = String(bytes, Charsets.UTF_8)
        return if (looksBinary(loose)) null else loose
    }

    private fun strictUtf8(bytes: ByteArray): String? = try {
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
        dec.decode(java.nio.ByteBuffer.wrap(bytes)).toString()
    } catch (_: Exception) {
        null
    }

    private fun decodeCharset(bytes: ByteArray, charset: String): String? = try {
        val dec = java.nio.charset.Charset.forName(charset).newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
        dec.decode(java.nio.ByteBuffer.wrap(bytes)).toString()
    } catch (_: Exception) {
        null
    }

    /** 文本里出现 NUL 或大量替换符 → 大概率不是文本 */
    private fun looksBinary(s: String): Boolean {
        if (s.isEmpty()) return false
        if (s.indexOf('\u0000') >= 0) return true
        var bad = 0
        val limit = minOf(s.length, 4096)
        for (i in 0 until limit) {
            val c = s[i]
            if (c == '\uFFFD' || (c < ' ' && c != '\n' && c != '\r' && c != '\t')) bad++
        }
        return bad.toFloat() / limit > 0.05f
    }

    /** 人类可读的文件大小 */
    fun sizeText(size: Long): String = when {
        size <= 0 -> ""
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> String.format("%.1f KB", size / 1024.0)
        else -> String.format("%.1f MB", size / 1024.0 / 1024.0)
    }

    /** 附件类型 → 图标标签（纯文字，不用 emoji） */
    fun typeLabel(type: String): String = when (type) {
        "image" -> "图片"
        "text" -> "文本"
        else -> "文件"
    }

    /** 附件类型 → 缩略标记（单个汉字，画在图标框里） */
    fun typeBadge(type: String): String = when (type) {
        "image" -> "图"
        "text" -> "文"
        else -> "件"
    }
}
