package xie.wsai.top

import android.content.ContentValues
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var spTheme: Spinner
    private lateinit var spProvider: Spinner
    private lateinit var configFields: LinearLayout
    private lateinit var baseUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var btnToggleKey: ImageButton
    private lateinit var modelName: EditText
    private lateinit var modelHint: TextView
    private lateinit var btnFetch: Button
    private lateinit var systemPrompt: EditText
    private lateinit var bgUrl: EditText
    private lateinit var seekScale: SeekBar
    private lateinit var scaleVal: TextView
    private lateinit var seekFont: SeekBar
    private lateinit var fontVal: TextView

    private lateinit var themeValues: Array<String>
    private lateinit var providerValues: Array<String>
    private var loading = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        ChatStore.init(this)
        setContentView(R.layout.activity_settings)

        themeValues = resources.getStringArray(R.array.theme_values)
        providerValues = resources.getStringArray(R.array.provider_values)

        bindViews()
        setupSpinners()
        setupListeners()
        loadState()
        applyBg()

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun themes(): Theme {
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return Themes.byKey(Prefs.theme, dark)
    }

    private fun applyBg() {
        val t = themes()
        findViewById<View>(R.id.root).background =
            Ui.vGradient(Ui.blend(t.bg, t.primary, if (t.isDark) 0.10f else 0.05f), t.bg)
        findViewById<ImageButton>(R.id.btnBack).setColorFilter(t.text)
        seekScale.progressTintList = ColorStateList.valueOf(t.primary)
        seekScale.thumbTintList = ColorStateList.valueOf(t.accent)
        seekFont.progressTintList = ColorStateList.valueOf(t.primary)
        seekFont.thumbTintList = ColorStateList.valueOf(t.accent)
        styleControls(t)
    }

    private fun styleControls(t: Theme) {
        val d = resources.displayMetrics.density
        // 分组卡片：圆角面板 + 细描边
        listOf(R.id.cardDisplay, R.id.cardLook, R.id.cardPersona, R.id.cardModel, R.id.cardActions).forEach { id ->
            findViewById<View>(id).background = Ui.panel(t.surface, 16f * d, t.border, 1f * d)
        }
        // 所有带 tag 的静态文字跟随主题色，标签前加主题色圆点装饰
        fun styleTexts(v: View) {
            when (v.tag) {
                "lbl" -> if (v is TextView) {
                    v.setTextColor(t.dim)
                    val dot = ContextCompat.getDrawable(this, R.drawable.ic_dot)?.mutate()
                    dot?.setTint(t.primary)
                    v.setCompoundDrawablesWithIntrinsicBounds(dot, null, null, null)
                    v.compoundDrawablePadding = (6 * resources.displayMetrics.density).toInt()
                }
                "lblText" -> if (v is TextView) v.setTextColor(t.text)
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) styleTexts(v.getChildAt(i))
        }
        styleTexts(findViewById(R.id.root))
        // 下拉框：圆角面板 + 主题色边框 + 主题色箭头 + 主题色弹出层
        listOf(spTheme, spProvider).forEach { sp ->
            sp.popupBackground = Ui.panel(t.surface, 14f * d, t.border, 1f * d)
            sp.background = Ui.panel(t.surface, 14f * d, t.border, 1f * d)
            (sp.adapter as? ThemedAdapter)?.apply { this.t = t; notifyDataSetChanged() }
        }
        // 按钮：圆角主题色 + 按压缩放（清掉 Material 主题默认的紫色 tint，否则主题色背景会被 tint 成紫）
        listOf(R.id.btnBgPick, R.id.btnBgApply, R.id.btnBgClear, R.id.btnExport, R.id.btnFetch, R.id.btnReset, R.id.btnProbe).forEach { id ->
            findViewById<Button>(id).apply {
                background = Ui.round(t.primary, 14f * d)
                backgroundTintList = null
                stateListAnimator = null
                elevation = 0f
                setTextColor(Color.WHITE)
                Ui.pressScale(this)
            }
        }
        findViewById<Button>(R.id.btnClear).apply {
            background = Ui.round(Color.parseColor("#E5484D"), 14f * d)
            backgroundTintList = null
            stateListAnimator = null
            elevation = 0f
            setTextColor(Color.WHITE)
            Ui.pressScale(this)
        }
        // 输入框：圆角面板 + 描边（清 tint，避免 Material 默认紫色下划线）；聚焦时描边高亮
        listOf(baseUrl, apiKey, modelName, systemPrompt, bgUrl).forEach { et ->
            et.setTextColor(t.text)
            et.setHintTextColor(t.dim)
            et.background = Ui.panel(t.surface, 12f * d, t.border, 1f * d)
            et.backgroundTintList = null
            et.setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
            et.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
                et.background = Ui.panel(
                    t.surface, 12f * d,
                    if (hasFocus) Ui.withAlpha(t.primary, 210) else t.border,
                    if (hasFocus) 1.8f * d else 1f * d)
            }
        }
        btnToggleKey.setColorFilter(t.primary)
    }

    private inner class ThemedAdapter(
        context: Context,
        items: Array<String>,
        var t: Theme
    ) : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, items) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tv = super.getView(position, convertView, parent) as TextView
            tv.setTextColor(t.text)
            tv.gravity = Gravity.CENTER_VERTICAL
            val d = resources.displayMetrics.density
            val pad = (18 * d).toInt()
            tv.setPadding(pad, 0, pad, 0)
            // 主题色下拉箭头（替换掉被自定义背景盖掉的默认箭头）
            val arrow = ContextCompat.getDrawable(context, R.drawable.ic_arrow_down)?.mutate()
            arrow?.setTint(t.primary)
            tv.setCompoundDrawablesWithIntrinsicBounds(null, null, arrow, null)
            tv.compoundDrawablePadding = (8 * d).toInt()
            return tv
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tv = super.getDropDownView(position, convertView, parent) as TextView
            tv.setTextColor(t.text)
            tv.setBackgroundColor(t.surface)
            val padX = (20 * resources.displayMetrics.density).toInt()
            val padY = (14 * resources.displayMetrics.density).toInt()
            tv.setPadding(padX, padY, padX, padY)
            return tv
        }
    }

    private fun bindViews() {
        spTheme = findViewById(R.id.spTheme)
        spProvider = findViewById(R.id.spProvider)
        configFields = findViewById(R.id.configFields)
        baseUrl = findViewById(R.id.baseUrl)
        apiKey = findViewById(R.id.apiKey)
        btnToggleKey = findViewById(R.id.btnToggleKey)
        modelName = findViewById(R.id.modelName)
        modelHint = findViewById(R.id.modelHint)
        btnFetch = findViewById(R.id.btnFetch)
        systemPrompt = findViewById(R.id.systemPrompt)
        bgUrl = findViewById(R.id.bgUrl)
        seekScale = findViewById(R.id.seekScale)
        scaleVal = findViewById(R.id.scaleVal)
        seekFont = findViewById(R.id.seekFont)
        fontVal = findViewById(R.id.fontVal)
    }

    private fun setupSpinners() {
        spTheme.adapter = ThemedAdapter(this, resources.getStringArray(R.array.theme_names), themes())
        spProvider.adapter = ThemedAdapter(this, resources.getStringArray(R.array.provider_names), themes())

        spTheme.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (loading) return
                Prefs.theme = themeValues[pos]
                applyBg()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        spProvider.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (loading) return
                Prefs.provider = providerValues[pos]
                onProviderChanged()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun setupListeners() {
        baseUrl.doAfterTextChanged { Prefs.setBaseUrlOf(Prefs.provider, it.toString()) }
        modelName.doAfterTextChanged { Prefs.setModelNameOf(Prefs.provider, it.toString()) }
        apiKey.doAfterTextChanged { Prefs.setApiKey(Prefs.provider, it.toString()) }
        systemPrompt.doAfterTextChanged { Prefs.systemPrompt = it.toString() }

        seekScale.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                val v = 60 + (p / 5) * 5
                scaleVal.text = "$v%"
                if (!loading) Prefs.uiScale = v
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        seekFont.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                val v = 12 + p
                fontVal.text = "${v}px"
                if (!loading) Prefs.fontSize = v
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        btnFetch.setOnClickListener { fetchModels() }
        findViewById<Button>(R.id.btnProbe).setOnClickListener { probeCapabilities() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { export() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { confirmClear() }
        findViewById<Button>(R.id.btnReset).setOnClickListener { confirmReset() }
        findViewById<Button>(R.id.btnBgPick).setOnClickListener { bgPickLauncher.launch("image/*") }
        findViewById<Button>(R.id.btnBgApply).setOnClickListener { saveBgFromUrl(bgUrl.text.toString().trim()) }
        findViewById<Button>(R.id.btnBgClear).setOnClickListener {
            Prefs.clearBg()
            toast("已清除背景图")
        }

        // API Key 明文/密文切换
        btnToggleKey.setOnClickListener {
            val isHidden = apiKey.inputType ==
                (android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
            val cur = apiKey.selectionStart
            apiKey.inputType = if (isHidden)
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            apiKey.typeface = Typeface.DEFAULT
            apiKey.setSelection(cur.coerceIn(0, apiKey.text.length))
            btnToggleKey.setImageResource(if (isHidden) R.drawable.ic_eye_off else R.drawable.ic_eye)
        }
    }

    private fun confirmReset() {
        val dlg = AlertDialog.Builder(this)
            .setTitle("恢复默认设置")
            .setMessage("将清除所有自定义配置（主题、背景图、模型配置、人格设定、开关等），聊天记录会保留。确定吗？")
            .setPositiveButton("恢复默认") { _, _ ->
                Prefs.resetAll()
                toast("已恢复默认设置")
                finish()
            }
            .setNegativeButton("取消", null)
            .show()
        val t = themes()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(t.primary)
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(t.primary)
    }

    private fun loadState() {
        loading = true
        // 先捕获已保存值（listener 被 loading 挡住，不会被 spinner 初始选中覆盖）
        val savedTheme = Prefs.theme
        val savedProvider = Prefs.provider
        val savedBase = Prefs.baseUrlOf(savedProvider)
        val savedModel = Prefs.modelNameOf(savedProvider)

        spTheme.setSelection(themeValues.indexOf(savedTheme).coerceAtLeast(0))
        spProvider.setSelection(providerValues.indexOf(savedProvider).coerceAtLeast(0))
        onProviderChanged()
        if (savedProvider != "zhipu_free") {
            baseUrl.setText(savedBase)
            modelName.setText(savedModel)
        }
        systemPrompt.setText(Prefs.systemPrompt)
        seekScale.progress = (Prefs.uiScale - 60).coerceIn(0, 90)
        scaleVal.text = "${Prefs.uiScale}%"
        seekFont.progress = (Prefs.fontSize - 12).coerceIn(0, 8)
        fontVal.text = "${Prefs.fontSize}px"
        loading = false
    }

    private fun onProviderChanged() {
        val isFree = Prefs.provider == "zhipu_free"
        configFields.visibility = if (isFree) View.GONE else View.VISIBLE
        if (!isFree) {
            val savedBase = Prefs.baseUrlOf(Prefs.provider)
            baseUrl.setText(if (savedBase.isNotEmpty()) savedBase else (ApiClient.PRESETS[Prefs.provider] ?: ""))
            modelName.setText(Prefs.modelNameOf(Prefs.provider))
            apiKey.setText(Prefs.apiKey(Prefs.provider))
            modelHint.text = "点击「提取」从 API 获取最新模型列表"
        } else {
            modelHint.text = "免费版无需配置"
        }
    }

    private fun fetchModels() {
        val base = baseUrl.text.toString().trim()
        val key = apiKey.text.toString().trim()
        if (base.isEmpty() || key.isEmpty()) { toast("请先填 Base URL 和 API Key"); return }
        btnFetch.isEnabled = false
        btnFetch.text = "提取中…"
        ApiClient.fetchModels(base, key,
            onResult = { models -> runOnUiThread {
                btnFetch.isEnabled = true; btnFetch.text = "提取"
                showModelPicker(models)
            } },
            onError = { e -> runOnUiThread {
                btnFetch.isEnabled = true; btnFetch.text = "提取"
                toast("提取失败：$e")
            } })
    }

    private fun showModelPicker(models: List<String>) {
        val arr = models.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("选择模型（${models.size}）")
            .setItems(arr) { _, i -> modelName.setText(arr[i]) }
            .show()
    }

    /** 实测探测当前模型是否支持深度思考 / 联网搜索，结果缓存并显示 */
    private fun probeCapabilities() {
        val base = baseUrl.text.toString().trim()
        val key = apiKey.text.toString().trim()
        val model = modelName.text.toString().trim()
        if (base.isEmpty() || key.isEmpty() || model.isEmpty()) {
            toast("请先填好 Base URL / API Key / 模型名称")
            return
        }
        val cfg = ApiConfig(base, key, model)
        val btn = findViewById<Button>(R.id.btnProbe)
        btn.isEnabled = false
        btn.text = "检测中…"
        modelHint.text = "正在检测…"
        ApiClient.probeCapabilities(cfg,
            onResult = { cap -> runOnUiThread {
                btn.isEnabled = true; btn.text = "检测模型能力（深度思考 / 联网搜索）"
                Prefs.setCap(Prefs.provider, model, cap)
                val d = when (cap.deep) {
                    CapResult.DEEP_PARAM -> "支持（需参数开启）"
                    CapResult.DEEP_AUTO -> "支持（模型自带）"
                    CapResult.DEEP_NONE -> "不支持"
                    else -> "未知"
                }
                val w = when (cap.web) {
                    CapResult.WEB_YES -> "支持"
                    CapResult.WEB_NO -> "不支持"
                    else -> "无法确认"
                }
                modelHint.text = "检测结果：深度思考 $d · 联网搜索 $w（已缓存，再次检测可刷新）"
                toast("检测完成：深度思考$d，联网搜索$w")
            } },
            onError = { e -> runOnUiThread {
                btn.isEnabled = true; btn.text = "检测模型能力（深度思考 / 联网搜索）"
                modelHint.text = "检测失败：$e"
                toast("检测失败：$e")
            } })
    }

    private fun export() {
        val list = ChatStore.load()
        if (list.isEmpty()) { toast("暂无聊天记录可导出"); return }
        val sb = StringBuilder()
        sb.append("聊天记录导出\n")
        sb.append("导出时间: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}\n")
        sb.append("=".repeat(40)).append("\n\n")
        for (m in list) {
            val role = if (m.role == "user") "用户" else "AI"
            sb.append("[$role] ${m.time}\n")
            sb.append(m.content).append("\n")
            if (m.attachments.isNotEmpty()) {
                sb.append("[附件: ")
                m.attachments.forEach { sb.append("${it.name} (${String.format("%.1fMB", it.size / 1024.0 / 1024.0)}) ") }
                sb.append("]\n")
            }
            sb.append("\n")
        }
        val filename = "chat_export_${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}.txt"
        saveToDownloads(filename, sb.toString())
    }

    private fun confirmClear() {
        val dlg = AlertDialog.Builder(this)
            .setTitle("清空聊天记录")
            .setMessage("确定要清空所有聊天记录吗？")
            .setPositiveButton("清空") { _, _ ->
                ChatStore.clear()
                MainActivity.pendingClear = true
                toast("聊天记录已清空")
                finish()
            }
            .setNegativeButton("取消", null)
            .show()
        val t = themes()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(t.primary)
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(t.primary)
    }

    private val bgPickLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveBgFromUri(uri)
    }

    private fun saveBgFromUri(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val f = File(filesDir, "bg_${System.currentTimeMillis()}.img")
            f.writeBytes(bytes)
            Prefs.bgImage = f.absolutePath
            toast("背景图已应用")
        } catch (e: Exception) {
            toast("应用失败：${e.message}")
        }
    }

    private fun saveBgFromUrl(url: String) {
        if (url.isBlank()) { toast("请输入图片 URL"); return }
        if (!url.startsWith("http://") && !url.startsWith("https://")) { toast("仅支持 http/https 链接"); return }
        toast("正在下载背景图…")
        Thread {
            try {
                val req = Request.Builder().url(url).build()
                val bytes = OkHttpClient().newCall(req).execute().use { it.body?.bytes() }
                    ?: return@Thread
                val f = File(filesDir, "bg_${System.currentTimeMillis()}.img")
                f.writeBytes(bytes)
                Prefs.bgImage = f.absolutePath
                runOnUiThread { toast("背景图已应用") }
            } catch (e: Exception) {
                runOnUiThread { toast("下载失败：${e.message}") }
            }
        }.start()
    }

    private fun saveToDownloads(filename: String, content: String) {
        try {
            val data = content.toByteArray(Charsets.UTF_8)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(
                    MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values
                )
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                }
                toast("已导出：$filename（见下载目录）")
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val f = File(dir, filename)
                FileOutputStream(f).use { it.write(data) }
                toast("已导出：$filename（见下载目录）")
            }
        } catch (e: Exception) {
            toast("导出失败：${e.message}")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
