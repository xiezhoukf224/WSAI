package xie.wsai.top

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * 语音识别封装（修复「有权限但语音输入没反应」）
 *
 * 旧实现的问题：
 * 1. 只调用 SpeechRecognizer.isRecognitionAvailable(ctx)，在 Android 11+ 受包可见性限制，
 *    未在 Manifest 声明 <queries> 时会直接返回 false → 一律走失败分支，点了没反应；
 * 2. 长按麦克风时用「按下即 start、松手 stopListening」的模型，短句常被识别器忽略，
 *    松手后既不回调结果也不回调错误，界面静默；
 * 3. 识别结束（onEndOfSpeech/onError）后没有兜底，一旦系统不回调结果，状态就永远挂着。
 *
 * 现在的做法：
 * - 优先「按住说话」：长按期间持续收音，松手即出结果；
 * - 若设备/系统不支持持续收音（很多手表语音助手只支持系统弹窗式识别），
 *   自动回退到系统语音界面（ACTION_RECOGNIZE_SPEECH），识别完把文字回填输入框；
 * - 两种方式都失败时，给出明确的原因提示（而不是默默无声）。
 */
class SpeechHelper(private val ctx: Context, private val cb: Callback) {

    interface Callback {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(code: Int)
        /** 需要回退到系统语音界面（返回 true 表示已由外部接管，回调不再触发） */
        fun onFallback(): Boolean
    }

    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private var finished = false
    private var hasResult = false
    private var lastPartial = ""

    companion object {
        /** 中文优先，其次系统语言，保证中文手表上识别语言正确 */
        fun pickLanguage(): String {
            val sys = Locale.getDefault().toString().replace('_', '-')
            return when {
                sys.startsWith("zh") -> "zh-CN"
                sys.startsWith("en") -> "en-US"
                else -> sys
            }
        }

        /** 判断设备是否有可用的语音识别服务（含 API 30+ 包可见性兜底） */
        fun available(ctx: Context): Boolean {
            if (SpeechRecognizer.isRecognitionAvailable(ctx)) return true
            return try {
                ctx.packageManager.queryIntentServices(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0
                ).isNotEmpty()
            } catch (_: Exception) {
                false
            }
        }
    }

    fun start() {
        destroy()
        if (!available(ctx)) {
            if (!cb.onFallback()) cb.onError(SpeechRecognizer.ERROR_RECOGNIZER_BUSY)
            return
        }
        finished = false
        hasResult = false
        lastPartial = ""

        val r = try {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        } catch (_: Exception) {
            null
        }
        if (r == null) {
            if (!cb.onFallback()) cb.onError(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        recognizer = r

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onEndOfSpeech() {
                // 部分机型不回调 onResults，这里做超时兜底，避免界面一直挂在「录音中」
                main.postDelayed({ finishWith(lastPartial) }, 1200)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = firstResult(partialResults)
                if (t.isNotEmpty()) {
                    lastPartial = t
                    cb.onPartial(t)
                }
            }

            override fun onResults(results: Bundle?) {
                finishWith(firstResult(results).ifEmpty { lastPartial })
            }

            override fun onError(error: Int) {
                if (finished) return
                // 有临时结果（如用户停顿）时，直接用已有内容，不再报错
                if (lastPartial.isNotEmpty()) {
                    finishWith(lastPartial)
                    return
                }
                finished = true
                // 系统识别服务缺失 / 不支持持续收音：交给外部用系统语音界面兜底
                val needFallback = error == SpeechRecognizer.ERROR_CLIENT ||
                    error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                    error == SpeechRecognizer.ERROR_SERVER
                if (needFallback && cb.onFallback()) return
                cb.onError(error)
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, pickLanguage())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, pickLanguage())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            if (Build.VERSION.SDK_INT >= 23) {
                // 手表上无声时长的限制更宽松一些，避免刚按就被判「没说话」
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
            }
        }
        try {
            r.startListening(intent)
        } catch (_: Exception) {
            if (!cb.onFallback()) cb.onError(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""

    private fun finishWith(text: String) {
        if (finished) return
        finished = true
        hasResult = text.isNotEmpty()
        main.removeCallbacksAndMessages(null)
        if (hasResult) cb.onFinal(text) else cb.onError(SpeechRecognizer.ERROR_NO_MATCH)
        destroy()
    }

    /** 松手：请求出结果（会触发 onResults） */
    fun stop() {
        try { recognizer?.stopListening() } catch (_: Exception) {}
        // 保险：若 2 秒内系统仍无回调，用已有的临时结果收尾
        main.postDelayed({ if (!finished) finishWith(lastPartial) }, 2000)
    }

    /** 取消本次识别（不触发任何回调），用于短按麦克风等误触场景 */
    fun cancel() {
        finished = true
        main.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        destroy()
    }

    fun destroy() {
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }
}
