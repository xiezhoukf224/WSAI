package xie.wsai.top

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan

object Markdown {
    /**
     * 简易 Markdown 渲染：
     * - ``` 代码块（等宽 + 背景）
     * - # / ## / ### 标题（加粗 + 放大）
     * - > 引用（斜体 + 灰色）
     * - - / * / 1. 列表项
     * - --- 分割线
     * - `行内代码`、**加粗**、*斜体*、[链接](url)
     */
    fun render(text: String, codeBg: Int, dim: Int = 0xFF8A8A9A.toInt(), primary: Int = 0xFF3B82F6.toInt()): Spanned {
        val out = SpannableStringBuilder()
        val parts = text.split(Regex("```"))
        for (i in parts.indices) {
            if (i % 2 == 1) {
                val cs = SpannableStringBuilder(parts[i].trim('\n'))
                cs.setSpan(BackgroundColorSpan(codeBg), 0, cs.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                cs.setSpan(TypefaceSpan("monospace"), 0, cs.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.append(cs)
            } else {
                out.append(renderBlock(parts[i], codeBg, dim, primary))
            }
        }
        return out
    }

    /** 块级处理：标题 / 引用 / 列表 / 分割线，逐行 */
    private fun renderBlock(text: String, codeBg: Int, dim: Int, primary: Int): Spanned {
        val sb = SpannableStringBuilder()
        val lines = text.split("\n")
        for ((i, line) in lines.withIndex()) {
            if (i > 0) sb.append("\n")
            when {
                line.startsWith("### ") -> appendHeading(sb, line.removePrefix("### "), 1.05f, codeBg, dim, primary)
                line.startsWith("## ") -> appendHeading(sb, line.removePrefix("## "), 1.12f, codeBg, dim, primary)
                line.startsWith("# ") -> appendHeading(sb, line.removePrefix("# "), 1.2f, codeBg, dim, primary)
                line.startsWith("> ") -> appendQuote(sb, line.removePrefix("> "), codeBg, dim, primary)
                line.startsWith("- ") || line.startsWith("* ") ->
                    sb.append(renderInline("• ${line.substring(2)}", codeBg, dim, primary))
                Regex("^\\d+\\.\\s").containsMatchIn(line) -> {
                    val dot = line.indexOf(". ")
                    sb.append(renderInline("${line.substring(0, dot + 1)} ${line.substring(dot + 2)}", codeBg, dim, primary))
                }
                line.trim() == "---" || line.trim() == "***" || line.trim() == "___" ->
                    sb.append(renderInline("─".repeat(22), codeBg, dim, primary))
                else -> sb.append(renderInline(line, codeBg, dim, primary))
            }
        }
        return sb
    }

    private fun appendHeading(sb: SpannableStringBuilder, text: String, scale: Float, codeBg: Int, dim: Int, primary: Int) {
        val s = SpannableStringBuilder(renderInline(text, codeBg, dim, primary))
        s.setSpan(RelativeSizeSpan(scale), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append(s)
    }

    private fun appendQuote(sb: SpannableStringBuilder, text: String, codeBg: Int, dim: Int, primary: Int) {
        val s = SpannableStringBuilder(renderInline(text, codeBg, dim, primary))
        s.setSpan(ForegroundColorSpan(dim), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.ITALIC), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("▍").append(s)
    }

    /** 行内：先切代码段，再处理链接 / 粗体 / 斜体 */
    private fun renderInline(text: String, codeBg: Int, dim: Int, primary: Int): Spanned {
        val sb = SpannableStringBuilder()
        var last = 0
        val re = Regex("`([^`]+)`")
        for (m in re.findAll(text)) {
            if (m.range.first > last) sb.append(renderLink(text.substring(last, m.range.first), primary))
            val cs = SpannableStringBuilder(m.groupValues[1])
            cs.setSpan(TypefaceSpan("monospace"), 0, cs.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            cs.setSpan(BackgroundColorSpan(codeBg), 0, cs.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(cs)
            last = m.range.last + 1
        }
        if (last < text.length) sb.append(renderLink(text.substring(last), primary))
        return sb
    }

    private fun renderLink(text: String, primary: Int): Spanned {
        val sb = SpannableStringBuilder()
        var last = 0
        val re = Regex("\\[([^\\[\\]]+)]\\(([^)\\s]+)\\)")
        for (m in re.findAll(text)) {
            if (m.range.first > last) sb.append(renderBoldItalic(text.substring(last, m.range.first)))
            val ls = SpannableStringBuilder(m.groupValues[1])
            ls.setSpan(URLSpan(m.groupValues[2]), 0, ls.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            ls.setSpan(ForegroundColorSpan(primary), 0, ls.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(ls)
            last = m.range.last + 1
        }
        if (last < text.length) sb.append(renderBoldItalic(text.substring(last)))
        return sb
    }

    private fun renderBoldItalic(text: String): Spanned {
        val sb = SpannableStringBuilder()
        var last = 0
        val re = Regex("\\*\\*(.*?)\\*\\*")
        for (m in re.findAll(text)) {
            if (m.range.first > last) sb.append(renderItalic(text.substring(last, m.range.first)))
            val bs = SpannableStringBuilder(m.groupValues[1])
            bs.setSpan(StyleSpan(Typeface.BOLD), 0, bs.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(bs)
            last = m.range.last + 1
        }
        if (last < text.length) sb.append(renderItalic(text.substring(last)))
        return sb
    }

    private fun renderItalic(text: String): Spanned {
        val sb = SpannableStringBuilder()
        var last = 0
        val re = Regex("\\*([^*\\s][^*]*)\\*")
        for (m in re.findAll(text)) {
            if (m.range.first > last) sb.append(text.substring(last, m.range.first))
            val is_ = SpannableStringBuilder(m.groupValues[1])
            is_.setSpan(StyleSpan(Typeface.ITALIC), 0, is_.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(is_)
            last = m.range.last + 1
        }
        if (last < text.length) sb.append(text.substring(last))
        return sb
    }
}
