package xie.wsai.top

import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ApiConfig(val baseUrl: String, val apiKey: String, val model: String)

object ApiClient {
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    @Volatile
    private var currentCall: Call? = null

    fun cancel() {
        try { currentCall?.cancel() } catch (_: Exception) {}
    }

    val FREE = ApiConfig(
        "https://open.bigmodel.cn/api/paas/v4",
        "dab0ca6aa8534771a4a5df6e41b1995a.2IPjPNlFakKn3kaw",
        "glm-4-flash"
    )

    val PRESETS = mapOf(
        "deepseek" to "https://api.deepseek.com/v1",
        "zhipu" to "https://open.bigmodel.cn/api/paas/v4",
        "qwen" to "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "moonshot" to "https://api.moonshot.cn/v1",
        "openai" to "https://api.openai.com/v1",
        "custom" to ""
    )

    // ---------------- 消息内容构造（附件不再是一段乱码） ----------------

    /** 纯文本消息 */
    fun msg(role: String, content: String): JSONObject = JSONObject().apply {
        put("role", role)
        put("content", content)
    }

    /** 多模态消息：content 为 [{type:"text"},{type:"image_url"}] 数组（OpenAI 兼容格式） */
    fun msgParts(role: String, parts: List<JSONObject>): JSONObject = JSONObject().apply {
        put("role", role)
        put("content", JSONArray().apply { parts.forEach { put(it) } })
    }

    fun textPart(text: String): JSONObject = JSONObject().apply {
        put("type", "text")
        put("text", text)
    }

    /** 图片：data:image/jpeg;base64,xxxx（视觉模型能直接看懂） */
    fun imagePart(dataUrl: String): JSONObject = JSONObject().apply {
        put("type", "image_url")
        put("image_url", JSONObject().put("url", dataUrl))
    }

    /** 兼容部分只认旧字段的中转站：{"type":"image_url","image_url":"data:..."} */
    private fun imagePartFlat(dataUrl: String): JSONObject = JSONObject().apply {
        put("type", "image_url")
        put("image_url", dataUrl)
    }

    /**
     * 联网搜索 / 深度思考：按厂商精确传参。
     * 统一发 enable_search 会让一堆模型直接 4xx 报错，这是「开了联网搜索 AI 就用不了」的根因。
     * - 智谱 bigmodel：tools=[web_search]（官方联网搜索方式，不认 enable_search）
     * - 通义 dashscope：enable_search（兼容模式原生参数）
     * - DeepSeek：search（V3.1+ 官方联网搜索参数）
     * - Moonshot：tools=[builtin_function $web_search]
     * - OpenAI / 自定义（中转站）：按模型名推断厂商再传参；完全认不出的模型不传，避免 400
     */
    fun buildExtra(cfg: ApiConfig, deepThink: Boolean, webSearch: Boolean, cap: CapResult? = null): JSONObject {
        val extra = JSONObject()
        val base = cfg.baseUrl.lowercase()
        val model = cfg.model.lowercase()
        val isZhipu = base.contains("bigmodel.cn")
        val isQwen = base.contains("dashscope")
        val isDeepseek = base.contains("deepseek")
        val isMoonshot = base.contains("moonshot")

        if (deepThink) {
            when {
                // 智谱：glm-4 系列用 enable_thinking；glm-4.5+ 用 thinking 对象参数
                isZhipu -> zhipuThinkingParam(model)?.let { putParam(extra, it.first, true) }
                isQwen -> putParam(extra, "enable_thinking", true)
                else -> when {
                    // 探测出的可用参数最可信（证据驱动，不看模型名）
                    cap?.deep == CapResult.DEEP_PARAM && cap.deepParam != null ->
                        putParam(extra, cap.deepParam, true)
                    // 模型名带厂商特征时按对应参数（探测失败时的兜底）
                    model.contains("glm") -> zhipuThinkingParam(model)?.let { putParam(extra, it.first, true) }
                    model.contains("qwen") -> putParam(extra, "enable_thinking", true)
                    // 自带思考的模型（reasoner/pro/flash 等）无需参数，不传
                }
            }
        } else if (cap?.deep == CapResult.DEEP_AUTO && cap.deepCloseable && cap.deepParam != null) {
            // 模型自带思考且探测确认可关闭：传关闭参数，让"关闭开关"真正生效
            putParam(extra, cap.deepParam, false)
        } else {
            // 未开启深度思考：对「默认就会思考」的模型显式关闭（无探测结果时的兜底）
            when {
                // DeepSeek V3.1+ 的 deepseek-chat 默认思考，必须显式关闭（reasoner 无法关闭，跳过）
                model.contains("deepseek") && model.contains("chat") && !model.contains("reasoner") ->
                    extra.put("thinking", JSONObject().put("type", "disabled"))
                // 通义 qwen3 系列部分型号默认思考，显式关闭（官方或中转站都适用）
                model.contains("qwen") -> extra.put("enable_thinking", false)
            }
        }
        if (webSearch) {
            when {
                isZhipu -> extra.put("tools", JSONArray().put(JSONObject().apply {
                    put("type", "web_search")
                    put("web_search", JSONObject().put("enable", true))
                }))
                isQwen -> extra.put("enable_search", true)
                isDeepseek -> extra.put("search", true)
                isMoonshot -> extra.put("tools", JSONArray().put(JSONObject().apply {
                    put("type", "builtin_function")
                    put("function", JSONObject().put("name", "\$web_search"))
                }))
                // 中转站：按模型名传对应厂商参数
                else -> when {
                    model.contains("deepseek") && !model.contains("reasoner") -> extra.put("search", true)
                    model.contains("qwen") -> extra.put("enable_search", true)
                    model.contains("glm") && !model.contains("flash") -> extra.put("tools", JSONArray().put(JSONObject().apply {
                        put("type", "web_search")
                        put("web_search", JSONObject().put("enable", true))
                    }))
                }
            }
        }
        return extra
    }

    /** 按参数名写入思考/搜索参数（开启或关闭），值按参数类型生成 */
    private fun putParam(extra: JSONObject, name: String, on: Boolean) {
        when (name) {
            "thinking" -> extra.put("thinking", JSONObject().put("type", if (on) "enabled" else "disabled"))
            "enable_thinking" -> extra.put("enable_thinking", on)
            "search" -> extra.put("search", on)
            "enable_search" -> extra.put("enable_search", on)
        }
    }

    /** 智谱思考参数：glm-4.5+ 用 thinking 对象，其余 glm-4 系列用 enable_thinking */
    private fun zhipuThinkingParam(model: String): Pair<String, Any>? {
        val m = model.lowercase()
        return if (m.contains("glm-4.5") || m.contains("glm-4.6") || m.contains("glm-4.7") ||
            m.contains("glm-5") || m.contains("glm-5.")) {
            "thinking" to JSONObject().put("type", "enabled")
        } else if (m.contains("glm")) {
            "enable_thinking" to true
        } else null
    }

    /**
     * 证据驱动探测模型能力（不靠模型名猜）：
     * 1. 深度思考：发一个需要推理的问题，检查响应里是否真的出现 reasoning_content 字段
     *    - 不带参数就有 → 模型自带思考（DEEP_AUTO），再验证能否用参数关闭
     *    - 带参数才有 → DEEP_PARAM（记录真正生效的参数名）
     *    - 都没有 → 不支持（有证据）
     * 2. 联网搜索：带搜索参数问实时问题，检查回复里是否有联网证据
     * onResult(cap)：探测完成；onError：无法得出结果（网络/鉴权等）
     */
    fun probeCapabilities(
        cfg: ApiConfig,
        onResult: (CapResult) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                // ---- 深度思考探测 ----
                var deep = CapResult.DEEP_NONE
                var deepParam: String? = null
                var closeable = false

                val auto = probeReasoning(cfg, null)
                when (auto) {
                    true -> {
                        // 不带参数就会思考 → 模型自带思考
                        deep = CapResult.DEEP_AUTO
                        val closed = probeReasoning(cfg) { o ->
                            o.put("thinking", JSONObject().put("type", "disabled"))
                        }
                        closeable = closed == false // 传关闭参数后不再思考 = 可关闭
                        if (closeable) deepParam = "thinking"
                    }
                    false -> {
                        // 试 enable_thinking
                        when (val p1 = probeReasoning(cfg) { o -> o.put("enable_thinking", true) }) {
                            true -> { deep = CapResult.DEEP_PARAM; deepParam = "enable_thinking" }
                            false -> {
                                // 再试 thinking 对象参数
                                when (val p2 = probeReasoning(cfg) { o ->
                                    o.put("thinking", JSONObject().put("type", "enabled"))
                                }) {
                                    true -> { deep = CapResult.DEEP_PARAM; deepParam = "thinking" }
                                    false -> deep = CapResult.DEEP_NONE
                                    null -> { onError("深度思考探测失败：网络或鉴权错误"); return@Thread }
                                }
                            }
                            null -> { onError("深度思考探测失败：网络或鉴权错误"); return@Thread }
                        }
                    }
                    null -> { onError("深度思考探测失败：网络或鉴权错误"); return@Thread }
                }

                // ---- 联网搜索探测 ----
                val web = probeWebSearch(cfg)
                if (web == null) {
                    onError("联网搜索探测失败：网络或鉴权错误")
                    return@Thread
                }
                onResult(CapResult(deep, deepParam, closeable, web))
            } catch (e: Exception) {
                onError(e.message ?: "探测失败")
            }
        }.start()
    }

    /** 深度思考探测（流式，与真实聊天一致）：发推理题，看流式响应里是否出现 reasoning_content；null=请求失败 */
    private fun probeReasoning(cfg: ApiConfig, fill: ((JSONObject) -> Unit)?): Boolean? {
        val body = JSONObject()
        body.put("model", cfg.model)
        body.put("stream", true)
        body.put("max_tokens", 300)
        body.put("messages", JSONArray().put(JSONObject().apply {
            put("role", "user")
            put("content", "请先进行详细推理再给出最终答案：三只猫三分钟捉三只老鼠，一百只猫捉一百只老鼠需要多少分钟？")
        }))
        fill?.invoke(body)
        val req = Request.Builder()
            .url(cfg.baseUrl.trimEnd('/') + "/chat/completions")
            .addHeader("Authorization", "Bearer ${cfg.apiKey}")
            .post(body.toString().toRequestBody(JSON))
            .build()
        return try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) null
                else {
                    val reader = resp.body?.charStream()?.buffered() ?: return@use null
                    var found = false
                    var line = reader.readLine()
                    while (line != null && !found) {
                        val t = line.trim()
                        if (t.startsWith("data:")) {
                            val data = t.removePrefix("data:").trim()
                            if (data.isNotEmpty() && data != "[DONE]") {
                                try {
                                    val delta = JSONObject(data)
                                        .optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                                    if (delta != null) {
                                        // 兼容两种字段名：reasoning_content（DeepSeek/智谱）与 reasoning（部分开源/中转）
                                        val r1 = delta.opt("reasoning_content")
                                        val r2 = delta.opt("reasoning")
                                        val hasR = (r1 != null && r1 != JSONObject.NULL && r1.toString().isNotBlank()) ||
                                            (r2 != null && r2 != JSONObject.NULL && r2.toString().isNotBlank())
                                        if (hasR) found = true
                                    }
                                } catch (_: Exception) { /* 忽略无法解析的行 */ }
                            }
                        }
                        line = reader.readLine()
                    }
                    found
                }
            }
        } catch (_: Exception) { null }
    }

    /**
     * 联网搜索探测：问"今天是几月几日"做日期验证。
     * 只有真正联网的模型才知道今天的真实日期（编不出来），这是硬证据。
     * 参数不被接受（400/422）= 不支持；模型说"无法联网"= 不支持；答出今天日期 = 支持；其余 = 无法确认
     */
    private fun probeWebSearch(cfg: ApiConfig): Int? {
        val model = cfg.model.lowercase()
        val todayZh = SimpleDateFormat("yyyy年M月d日", Locale.CHINESE).format(Date())
        val todayNum = SimpleDateFormat("yyyy-M-d", Locale.CHINESE).format(Date())
        val body = JSONObject()
        body.put("model", cfg.model)
        body.put("stream", false)
        body.put("max_tokens", 60)
        body.put("messages", JSONArray().put(JSONObject().apply {
            put("role", "user")
            put("content", "今天是几月几日？请联网查询后只回答日期。如果你无法联网，请只回答\"无法联网\"四个字。")
        }))
        // 搜索参数按模型名选最可能的形式（参数 400 也算不支持）
        when {
            model.contains("glm") -> body.put("tools", JSONArray().put(JSONObject().apply {
                put("type", "web_search")
                put("web_search", JSONObject().put("enable", true))
            }))
            model.contains("qwen") -> body.put("enable_search", true)
            else -> {
                body.put("search", true)
                body.put("enable_search", true)
            }
        }
        val req = Request.Builder()
            .url(cfg.baseUrl.trimEnd('/') + "/chat/completions")
            .addHeader("Authorization", "Bearer ${cfg.apiKey}")
            .post(body.toString().toRequestBody(JSON))
            .build()
        return try {
            client.newCall(req).execute().use { resp ->
                when {
                    // 参数不被接受（400/422）= 不支持联网搜索
                    !resp.isSuccessful -> {
                        if (resp.code == 400 || resp.code == 422) CapResult.WEB_NO else null
                    }
                    else -> {
                        val text = resp.body?.string() ?: ""
                        val content = try {
                            JSONObject(text)
                                .optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                                ?.opt("content")?.toString() ?: ""
                        } catch (_: Exception) { text }
                        val t = content.lowercase()
                        when {
                            // 模型明确说自己无法联网 → 不支持（证据）
                            t.contains("无法联网") || t.contains("不能联网") ||
                                t.contains("不具备联网") || t.contains("暂不支持联网") ||
                                t.contains("没有联网功能") -> CapResult.WEB_NO
                            // 答出今天的真实日期 → 确实联网了（硬证据，编不出来）
                            t.contains(todayZh.lowercase()) || t.contains(todayNum.lowercase()) -> CapResult.WEB_YES
                            // 其余（旧日期/拒绝回答/含糊）→ 无法确认，不谎报支持
                            else -> CapResult.WEB_UNKNOWN
                        }
                    }
                }
            }
        } catch (_: Exception) { null }
    }

    /** 取 delta 字段文本，过滤 JSON null / 字符串 "null" / 空值，避免消息里混入一堆 null */
    private fun deltaText(delta: JSONObject, key: String): String {
        val v = delta.opt(key)
        if (v == null || v == JSONObject.NULL) return ""
        val s = when (v) {
            // 新版模型 content 可能是数组格式：[{type:"text", text:"..."}]
            is JSONArray -> {
                val sb = StringBuilder()
                for (i in 0 until v.length()) {
                    val item = v.optJSONObject(i)
                    if (item != null) sb.append(item.optString("text"))
                    else sb.append(v.opt(i).toString())
                }
                sb.toString()
            }
            else -> v.toString()
        }
        return if (s == "null" || s.isBlank()) "" else s
    }

    /**
     * 流式对话：思考过程与回答都实时回调（增量）。
     *
     * fallbackMessages：附件走「图片视觉」格式时，若当前模型不支持视觉（接口报错），
     * 自动用这份「纯文本版消息」重试一次，避免用户上传图片后整个对话直接失败。
     */
    fun chatStream(
        cfg: ApiConfig,
        messages: List<JSONObject>,
        extra: JSONObject,
        onReasoning: (String) -> Unit,
        onContent: (String) -> Unit,
        onDone: (reasoning: String, content: String) -> Unit,
        onError: (String) -> Unit,
        fallbackMessages: List<JSONObject>? = null
    ) {
        Thread {
            var usedFallback = false
            var attempt = 0
            while (true) {
                attempt++
                val msgs = if (usedFallback) fallbackMessages!! else messages
                val call = client.newCall(buildChatRequest(cfg, msgs, extra, stream = true))
                currentCall = call
                val reasoning = StringBuilder()
                val content = StringBuilder()
                var retry = false
                try {
                    call.execute().use { resp ->
                        if (!resp.isSuccessful) {
                            val text = resp.body?.string() ?: ""
                            val err = parseError(text, resp.code)
                            // 图片格式不被支持 → 用纯文本版重试一次
                            if (!usedFallback && fallbackMessages != null && looksLikeVisionReject(err)) {
                                retry = true
                            } else {
                                onError(err)
                                return@Thread
                            }
                        } else {
                            val reader = resp.body?.charStream()?.buffered() ?: run {
                                onError("响应为空")
                                return@Thread
                            }
                            var parseErr: String? = null
                            parseSse(reader) { dr, dc, err ->
                                if (err != null) parseErr = err
                                else {
                                    if (dr.isNotEmpty()) {
                                        reasoning.append(dr)
                                        onReasoning(dr)
                                    }
                                    if (dc.isNotEmpty()) {
                                        content.append(dc)
                                        onContent(dc)
                                    }
                                }
                            }
                            if (parseErr != null) onError(parseErr!!)
                            else onDone(reasoning.toString(), content.toString())
                            return@Thread
                        }
                    }
                } catch (e: Exception) {
                    onError(if (call.isCanceled()) "已停止" else (e.message ?: "网络错误"))
                    return@Thread
                } finally {
                    currentCall = null
                }
                if (!retry || attempt >= 2) return@Thread
                usedFallback = true
            }
        }.start()
    }

    /** 接口错误像不像「不支持图片/多模态」 */
    private fun looksLikeVisionReject(err: String): Boolean {
        val e = err.lowercase()
        return (e.contains("image") || e.contains("vision") || e.contains("multimodal") ||
            e.contains("content") || e.contains("text only") || e.contains("不支持") ||
            e.contains("invalid type") || e.contains("array")) &&
            (e.contains("image") || e.contains("vision") || e.contains("multimodal") ||
                e.contains("不支持") || e.contains("invalid type"))
    }

    /** 逐行解析 SSE（data: {...} / data: [DONE]）；遇到 error 数据帧时停止解析 */
    private fun parseSse(reader: BufferedReader, onDelta: (r: String, c: String, err: String?) -> Unit) {
        var stopped = false
        var line = reader.readLine()
        while (line != null && !stopped) {
            val t = line.trim()
            if (t.startsWith("data:")) {
                val data = t.removePrefix("data:").trim()
                if (data.isNotEmpty() && data != "[DONE]") {
                    try {
                        val json = JSONObject(data)
                        if (json.has("error")) {
                            val msg = json.optJSONObject("error")?.optString("message") ?: "流式响应错误"
                            onDelta("", "", msg)
                            stopped = true
                        } else {
                            val choice = json.optJSONArray("choices")?.optJSONObject(0)
                            val delta = choice?.optJSONObject("delta")
                            if (delta != null) {
                                onDelta(
                                    deltaText(delta, "reasoning_content").ifEmpty { deltaText(delta, "reasoning") },
                                    deltaText(delta, "content"),
                                    null
                                )
                            }
                        }
                    } catch (_: Exception) {
                        // 忽略无法解析的行（如心跳 / 注释行）
                    }
                }
            }
            line = reader.readLine()
        }
    }

    fun fetchModels(
        baseUrl: String,
        apiKey: String,
        onResult: (List<String>) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val req = Request.Builder()
                    .url(baseUrl.trimEnd('/') + "/models")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .get()
                    .build()
                client.newCall(req).execute().use { resp ->
                    val text = resp.body?.string() ?: ""
                    if (!resp.isSuccessful) {
                        onError(parseError(text, resp.code))
                        return@Thread
                    }
                    onResult(parseModels(text))
                }
            } catch (e: Exception) {
                onError(e.message ?: "网络错误")
            }
        }.start()
    }

    private fun buildChatRequest(cfg: ApiConfig, messages: List<JSONObject>, extra: JSONObject, stream: Boolean): Request {
        val body = JSONObject()
        body.put("model", cfg.model)
        body.put("stream", stream)
        val arr = JSONArray()
        messages.forEach { arr.put(it) }
        body.put("messages", arr)
        val keys = extra.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            body.put(k, extra.get(k))
        }
        return Request.Builder()
            .url(cfg.baseUrl.trimEnd('/') + "/chat/completions")
            .addHeader("Authorization", "Bearer ${cfg.apiKey}")
            .post(body.toString().toRequestBody(JSON))
            .build()
    }

    private fun parseError(text: String, code: Int): String {
        return try {
            JSONObject(text).optJSONObject("error")?.optString("message") ?: "HTTP $code"
        } catch (_: Exception) {
            "HTTP $code"
        }
    }

    private fun parseModels(text: String): List<String> {
        val data = JSONObject(text)
        val models = mutableListOf<String>()
        fun collect(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                when (val item = arr.opt(i)) {
                    is JSONObject -> item.optString("id").takeIf { it.isNotEmpty() }?.let(models::add)
                    is String -> if (item.isNotEmpty()) models.add(item)
                }
            }
        }
        collect(data.optJSONArray("data"))
        collect(data.optJSONArray("models"))
        if (models.isEmpty()) {
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = data.optJSONArray(k)
                if (v != null) { collect(v); break }
            }
        }
        return models.distinct()
    }
}
